import React from 'react';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';
import { Button } from '@/components/ui/button';
import { Users, Calendar, Target, Coins } from 'lucide-react';

// Syndicate Card Component for displaying syndicate information
export const SyndicateCard = ({ syndicate }) => {
  const {
    name,
    lottery,
    type,
    riskLevel,
    financialEffort,
    totalShares,
    availableShares,
    sharePrice,
    startDate,
    tier,
    creator
  } = syndicate;

  const getRiskColor = (risk) => {
    switch (risk) {
      case 'Cautious': return 'bg-green-100 text-green-800';
      case 'Ambitious': return 'bg-yellow-100 text-yellow-800';
      case 'Audacious': return 'bg-red-100 text-red-800';
      default: return 'bg-gray-100 text-gray-800';
    }
  };

  const getTypeColor = (type) => {
    return type === 'Standard' ? 'bg-blue-100 text-blue-800' : 'bg-purple-100 text-purple-800';
  };

  return (
    <Card className="hover:shadow-lg transition-shadow cursor-pointer">
      <CardHeader>
        <div className="flex justify-between items-start">
          <CardTitle className="text-lg">{name}</CardTitle>
          <Badge className={getTypeColor(type)}>{type}</Badge>
        </div>
        <CardDescription className="flex items-center gap-2">
          <span className="font-medium">{lottery.name}</span>
          <span className="text-2xl">{lottery.flag}</span>
        </CardDescription>
      </CardHeader>
      <CardContent>
        <div className="space-y-3">
          <div className="flex justify-between items-center">
            <span className="text-sm text-gray-600">Risk Level:</span>
            <Badge className={getRiskColor(riskLevel)}>{riskLevel}</Badge>
          </div>
          
          <div className="flex justify-between items-center">
            <span className="text-sm text-gray-600">Financial Effort:</span>
            <Badge variant="outline">{financialEffort}</Badge>
          </div>
          
          <div className="flex justify-between items-center">
            <span className="text-sm text-gray-600">Tier Required:</span>
            <Badge variant="secondary">{tier}</Badge>
          </div>
          
          <div className="flex items-center gap-4 text-sm">
            <div className="flex items-center gap-1">
              <Users className="h-4 w-4" />
              <span>{availableShares}/{totalShares} shares</span>
            </div>
            <div className="flex items-center gap-1">
              <Coins className="h-4 w-4" />
              <span>£{sharePrice}</span>
            </div>
          </div>
          
          <div className="flex items-center gap-1 text-sm text-gray-600">
            <Calendar className="h-4 w-4" />
            <span>Starts {startDate}</span>
          </div>
          
          <div className="pt-2">
            <Button 
              className="w-full" 
              disabled={availableShares === 0}
            >
              {availableShares === 0 ? 'Fully Subscribed' : 'Join Syndicate'}
            </Button>
          </div>
        </div>
      </CardContent>
    </Card>
  );
};

// Lottery Card Component for displaying lottery information
export const LotteryCard = ({ lottery, onClick }) => {
  const { name, country, flag, format, nextDraw, jackpot } = lottery;
  
  return (
    <Card className="hover:shadow-lg transition-shadow cursor-pointer" onClick={onClick}>
      <CardHeader className="text-center">
        <div className="text-4xl mb-2">{flag}</div>
        <CardTitle className="text-lg">{name}</CardTitle>
        <CardDescription>{country}</CardDescription>
        <Badge variant="secondary" className="mx-auto w-fit">
          {format}
        </Badge>
      </CardHeader>
      <CardContent className="text-center">
        <div className="space-y-2">
          <div className="text-sm text-gray-600">Next Draw:</div>
          <div className="font-medium">{nextDraw}</div>
          <div className="text-sm text-gray-600">Estimated Jackpot:</div>
          <div className="text-lg font-bold text-primary">£{jackpot?.toLocaleString()}</div>
        </div>
      </CardContent>
    </Card>
  );
};

// Tier Badge Component
export const TierBadge = ({ tier, size = 'default' }) => {
  const getTierColor = (tierLevel) => {
    const colors = {
      1: 'bg-gray-100 text-gray-800',
      2: 'bg-green-100 text-green-800',
      3: 'bg-blue-100 text-blue-800',
      4: 'bg-purple-100 text-purple-800',
      5: 'bg-yellow-100 text-yellow-800',
      6: 'bg-orange-100 text-orange-800',
      7: 'bg-red-100 text-red-800',
      8: 'bg-pink-100 text-pink-800',
      9: 'bg-gradient-to-r from-yellow-400 to-orange-500 text-white'
    };
    return colors[tierLevel] || colors[1];
  };

  const sizeClasses = {
    sm: 'text-xs px-2 py-1',
    default: 'text-sm px-3 py-1',
    lg: 'text-base px-4 py-2'
  };

  return (
    <Badge className={`${getTierColor(tier.level)} ${sizeClasses[size]}`}>
      {tier.name}
    </Badge>
  );
};

// Statistics Card Component
export const StatCard = ({ icon, value, label, trend }) => {
  return (
    <Card>
      <CardContent className="p-6">
        <div className="flex items-center justify-between">
          <div>
            <p className="text-sm font-medium text-gray-600">{label}</p>
            <p className="text-2xl font-bold">{value}</p>
            {trend && (
              <p className={`text-sm ${trend > 0 ? 'text-green-600' : 'text-red-600'}`}>
                {trend > 0 ? '+' : ''}{trend}% from last month
              </p>
            )}
          </div>
          <div className="text-primary">
            {icon}
          </div>
        </div>
      </CardContent>
    </Card>
  );
};

// Loading Spinner Component
export const LoadingSpinner = ({ size = 'default' }) => {
  const sizeClasses = {
    sm: 'w-4 h-4',
    default: 'w-8 h-8',
    lg: 'w-12 h-12'
  };

  return (
    <div className={`animate-spin rounded-full border-2 border-gray-300 border-t-primary ${sizeClasses[size]}`}></div>
  );
};

// Empty State Component
export const EmptyState = ({ icon, title, description, action }) => {
  return (
    <div className="text-center py-12">
      <div className="text-gray-400 mb-4">
        {icon}
      </div>
      <h3 className="text-lg font-medium text-gray-900 mb-2">{title}</h3>
      <p className="text-gray-600 mb-6">{description}</p>
      {action && action}
    </div>
  );
};

// Filter Component
export const FilterSelect = ({ label, value, onChange, options, placeholder }) => {
  return (
    <div className="space-y-2">
      <label className="text-sm font-medium text-gray-700">{label}</label>
      <select
        value={value}
        onChange={(e) => onChange(e.target.value)}
        className="w-full px-3 py-2 border border-gray-300 rounded-md focus:outline-none focus:ring-2 focus:ring-primary focus:border-transparent"
      >
        <option value="">{placeholder}</option>
        {options.map((option) => (
          <option key={option.value} value={option.value}>
            {option.label}
          </option>
        ))}
      </select>
    </div>
  );
};

// Search Input Component
export const SearchInput = ({ value, onChange, placeholder }) => {
  return (
    <div className="relative">
      <input
        type="text"
        value={value}
        onChange={(e) => onChange(e.target.value)}
        placeholder={placeholder}
        className="w-full px-4 py-2 pl-10 border border-gray-300 rounded-md focus:outline-none focus:ring-2 focus:ring-primary focus:border-transparent"
      />
      <div className="absolute inset-y-0 left-0 pl-3 flex items-center pointer-events-none">
        <Target className="h-5 w-5 text-gray-400" />
      </div>
    </div>
  );
};

