from flask import Blueprint, request, jsonify
from src.models.user import db, Lottery, Syndicate, Share, Entry, DrawSchedule, DrawResult, Tier
from datetime import datetime, date
from sqlalchemy import desc, func

lottery_bp = Blueprint('lottery', __name__)

@lottery_bp.route('/lotteries', methods=['GET'])
def get_lotteries():
    """Get all active lotteries"""
    try:
        lotteries = Lottery.query.filter_by(is_active=True).all()
        return jsonify({
            'success': True,
            'data': [lottery.to_dict() for lottery in lotteries]
        })
    except Exception as e:
        return jsonify({
            'success': False,
            'error': str(e)
        }), 500

@lottery_bp.route('/lotteries/<int:lottery_id>', methods=['GET'])
def get_lottery(lottery_id):
    """Get a specific lottery by ID"""
    try:
        lottery = Lottery.query.get_or_404(lottery_id)
        return jsonify({
            'success': True,
            'data': lottery.to_dict()
        })
    except Exception as e:
        return jsonify({
            'success': False,
            'error': str(e)
        }), 500

@lottery_bp.route('/lotteries/<int:lottery_id>/next-draw', methods=['GET'])
def get_next_draw(lottery_id):
    """Get the next scheduled draw for a lottery"""
    try:
        lottery = Lottery.query.get_or_404(lottery_id)
        next_draw = DrawSchedule.query.filter(
            DrawSchedule.lottery_id == lottery_id,
            DrawSchedule.draw_date >= date.today(),
            DrawSchedule.is_completed == False
        ).order_by(DrawSchedule.draw_date.asc()).first()
        
        if next_draw:
            return jsonify({
                'success': True,
                'data': next_draw.to_dict()
            })
        else:
            return jsonify({
                'success': True,
                'data': None,
                'message': 'No upcoming draws scheduled'
            })
    except Exception as e:
        return jsonify({
            'success': False,
            'error': str(e)
        }), 500

@lottery_bp.route('/lotteries/<int:lottery_id>/recent-results', methods=['GET'])
def get_recent_results(lottery_id):
    """Get recent draw results for a lottery"""
    try:
        limit = request.args.get('limit', 10, type=int)
        results = DrawResult.query.filter_by(lottery_id=lottery_id)\
            .order_by(desc(DrawResult.draw_date))\
            .limit(limit).all()
        
        return jsonify({
            'success': True,
            'data': [result.to_dict() for result in results]
        })
    except Exception as e:
        return jsonify({
            'success': False,
            'error': str(e)
        }), 500

