import React, { createContext, useContext, useState, useEffect } from 'react';

// Translation Context
const TranslationContext = createContext();

// Translation data
const translations = {
  en: {
    // Navigation
    nav: {
      home: 'Home',
      chooseSyndicate: 'Choose Syndicate',
      createSyndicate: 'Create Syndicate',
      forum: 'Forum',
      members: 'Members',
      admin: 'Admin',
      login: 'Login',
      register: 'Register',
      logout: 'Logout',
      profile: 'Profile'
    },
    
    // Landing Page
    landing: {
      heroTitle: 'Join the World\'s Most Exciting Lottery Syndicates',
      heroSubtitle: 'Pool your resources with players worldwide across 9 international lotteries. Increase your chances, manage your risk, and unlock exclusive tier benefits.',
      browseSyndicates: 'Browse Syndicates',
      createSyndicate: 'Create Syndicate',
      
      // Syndicate Types
      syndicateTypes: 'Syndicate Types & Risk Management',
      syndicateTypesSubtitle: 'Choose the perfect syndicate type and risk level for your playing style',
      
      standardSyndicate: 'Standard Syndicates',
      standardDescription: 'Perfect for regular players',
      standardFeatures: [
        '10 shares of 10% each',
        'Run for 8 consecutive draws',
        'Up to 333 different number entries',
        'Lower investment, steady participation'
      ],
      
      superSyndicate: 'Super Syndicates',
      superDescription: 'For serious lottery enthusiasts',
      superFeatures: [
        '100 shares of 1% each',
        'Run for 4 consecutive draws',
        'Up to 999 different number entries',
        'Higher investment, maximum coverage'
      ],
      
      // Risk Levels
      cautious: 'Cautious',
      cautiousDescription: 'Steady approach with consistent participation',
      ambitious: 'Ambitious',
      ambitiousDescription: 'Balanced risk with good potential returns',
      audacious: 'Audacious',
      audaciousDescription: 'Maximum risk for maximum potential rewards',
      
      // Financial Effort
      minimum: 'Minimum',
      minimumDescription: 'Entry-level investment for casual players',
      medium: 'Medium',
      mediumDescription: 'Moderate investment for regular players',
      maximum: 'Maximum',
      maximumDescription: 'Premium investment for serious players',
      
      // Tier System
      tierSystem: '9-Tier Syndicate System',
      tierSystemSubtitle: 'Unlock exclusive benefits as you achieve winnings milestones',
      
      // Community Stats
      communityStats: 'Community & Statistics',
      communityStatsSubtitle: 'Join thousands of players worldwide in our lottery syndicates',
      activePlayers: 'Active Players',
      activeSyndicates: 'Active Syndicates',
      totalWinnings: 'Total Winnings',
      internationalLotteries: 'International Lotteries',
      
      // Available Lotteries
      availableLotteries: 'Available Lotteries',
      availableLotteriesSubtitle: 'Play across 9 international lotteries with our syndicate system',
      joinSyndicatesFor: 'Join syndicates for this lottery and increase your winning chances',
      
      // Call to Action
      readyToWin: 'Ready to Start Winning?',
      readyToWinSubtitle: 'Join José Mil-Lotto\'s Syndicates today and become part of the world\'s most exciting lottery community. Your next big win could be just one syndicate away!',
      joinNowFree: 'Join Now - It\'s Free!'
    },
    
    // Authentication
    auth: {
      login: 'Login',
      register: 'Register',
      firstName: 'First Name',
      lastName: 'Last Name',
      username: 'Username',
      email: 'Email',
      password: 'Password',
      confirmPassword: 'Confirm Password',
      termsAndConditions: 'I agree to the Terms & Conditions',
      createAccount: 'Create Account',
      signIn: 'Sign In',
      forgotPassword: 'Forgot Password?',
      alreadyHaveAccount: 'Already have an account?',
      dontHaveAccount: 'Don\'t have an account?',
      socialLogin: 'Or continue with',
      google: 'Google',
      facebook: 'Facebook',
      linkedin: 'LinkedIn'
    },
    
    // Syndicate Creation
    syndicate: {
      createNew: 'Create New Syndicate',
      createDescription: 'Set up your lottery syndicate and invite players to join',
      basicInformation: 'Basic Information',
      syndicateName: 'Syndicate Name',
      syndicateNamePlaceholder: 'Enter syndicate name',
      lottery: 'Lottery',
      selectLottery: 'Select a lottery',
      description: 'Description',
      descriptionPlaceholder: 'Describe your syndicate strategy and goals',
      
      syndicateConfiguration: 'Syndicate Configuration',
      riskFinancialSettings: 'Risk & Financial Settings',
      riskTolerance: 'Risk Tolerance',
      financialEffort: 'Financial Effort',
      
      syndicateSummary: 'Syndicate Summary',
      entryFee: 'Entry Fee',
      maxParticipants: 'Max Participants',
      draws: 'Draws',
      maxEntries: 'Max Entries',
      
      saveAsDraft: 'Save as Draft',
      createSyndicate: 'Create Syndicate'
    },
    
    // Tier System
    tiers: {
      currentTier: 'Current Tier',
      totalWinnings: 'Total Winnings',
      syndicatesJoined: 'Syndicates Joined',
      activeSyndicates: 'Active Syndicates',
      progressTo: 'Progress to',
      remaining: 'remaining',
      complete: 'complete',
      currentBenefits: 'Your Current Benefits:',
      tierSystemOverview: 'Tier System Overview',
      tierSystemDescription: 'Unlock new benefits and exclusive syndicate access as you achieve winnings milestones',
      moreBenefits: 'more benefits',
      current: 'Current',
      
      // Tier Names
      starter: 'Starter',
      explorer: 'Explorer',
      adventurer: 'Adventurer',
      specialist: 'Specialist',
      expert: 'Expert',
      master: 'Master',
      elite: 'Elite',
      champion: 'Champion',
      legend: 'Legend'
    },
    
    // Common
    common: {
      loading: 'Loading...',
      error: 'Error',
      success: 'Success',
      cancel: 'Cancel',
      save: 'Save',
      edit: 'Edit',
      delete: 'Delete',
      confirm: 'Confirm',
      back: 'Back',
      next: 'Next',
      previous: 'Previous',
      close: 'Close',
      search: 'Search',
      filter: 'Filter',
      sort: 'Sort',
      refresh: 'Refresh'
    }
  },
  
  pt: {
    // Navigation
    nav: {
      home: 'Início',
      chooseSyndicate: 'Escolher Sindicato',
      createSyndicate: 'Criar Sindicato',
      forum: 'Fórum',
      members: 'Membros',
      admin: 'Admin',
      login: 'Entrar',
      register: 'Registrar',
      logout: 'Sair',
      profile: 'Perfil'
    },
    
    // Landing Page
    landing: {
      heroTitle: 'Junte-se aos Sindicatos de Loteria Mais Emocionantes do Mundo',
      heroSubtitle: 'Una seus recursos com jogadores do mundo todo em 9 loterias internacionais. Aumente suas chances, gerencie seu risco e desbloqueie benefícios exclusivos.',
      browseSyndicates: 'Explorar Sindicatos',
      createSyndicate: 'Criar Sindicato',
      
      // Syndicate Types
      syndicateTypes: 'Tipos de Sindicato e Gestão de Risco',
      syndicateTypesSubtitle: 'Escolha o tipo de sindicato perfeito e nível de risco para seu estilo de jogo',
      
      standardSyndicate: 'Sindicatos Padrão',
      standardDescription: 'Perfeito para jogadores regulares',
      standardFeatures: [
        '10 cotas de 10% cada',
        'Duração de 8 sorteios consecutivos',
        'Até 333 combinações diferentes',
        'Investimento menor, participação constante'
      ],
      
      superSyndicate: 'Super Sindicatos',
      superDescription: 'Para entusiastas sérios de loteria',
      superFeatures: [
        '100 cotas de 1% cada',
        'Duração de 4 sorteios consecutivos',
        'Até 999 combinações diferentes',
        'Investimento maior, cobertura máxima'
      ],
      
      // Risk Levels
      cautious: 'Cauteloso',
      cautiousDescription: 'Abordagem estável com participação consistente',
      ambitious: 'Ambicioso',
      ambitiousDescription: 'Risco equilibrado com bom potencial de retorno',
      audacious: 'Audacioso',
      audaciousDescription: 'Risco máximo para recompensas máximas',
      
      // Financial Effort
      minimum: 'Mínimo',
      minimumDescription: 'Investimento básico para jogadores casuais',
      medium: 'Médio',
      mediumDescription: 'Investimento moderado para jogadores regulares',
      maximum: 'Máximo',
      maximumDescription: 'Investimento premium para jogadores sérios',
      
      // Tier System
      tierSystem: 'Sistema de 9 Níveis',
      tierSystemSubtitle: 'Desbloqueie benefícios exclusivos conforme alcança marcos de ganhos',
      
      // Community Stats
      communityStats: 'Comunidade e Estatísticas',
      communityStatsSubtitle: 'Junte-se a milhares de jogadores do mundo todo em nossos sindicatos de loteria',
      activePlayers: 'Jogadores Ativos',
      activeSyndicates: 'Sindicatos Ativos',
      totalWinnings: 'Ganhos Totais',
      internationalLotteries: 'Loterias Internacionais',
      
      // Available Lotteries
      availableLotteries: 'Loterias Disponíveis',
      availableLotteriesSubtitle: 'Jogue em 9 loterias internacionais com nosso sistema de sindicatos',
      joinSyndicatesFor: 'Junte-se a sindicatos desta loteria e aumente suas chances de ganhar',
      
      // Call to Action
      readyToWin: 'Pronto para Começar a Ganhar?',
      readyToWinSubtitle: 'Junte-se aos Sindicatos José Mil-Lotto hoje e faça parte da comunidade de loteria mais emocionante do mundo. Sua próxima grande vitória pode estar a apenas um sindicato de distância!',
      joinNowFree: 'Junte-se Agora - É Grátis!'
    },
    
    // Authentication
    auth: {
      login: 'Entrar',
      register: 'Registrar',
      firstName: 'Nome',
      lastName: 'Sobrenome',
      username: 'Nome de Usuário',
      email: 'Email',
      password: 'Senha',
      confirmPassword: 'Confirmar Senha',
      termsAndConditions: 'Concordo com os Termos e Condições',
      createAccount: 'Criar Conta',
      signIn: 'Entrar',
      forgotPassword: 'Esqueceu a senha?',
      alreadyHaveAccount: 'Já tem uma conta?',
      dontHaveAccount: 'Não tem uma conta?',
      socialLogin: 'Ou continue com',
      google: 'Google',
      facebook: 'Facebook',
      linkedin: 'LinkedIn'
    },
    
    // Syndicate Creation
    syndicate: {
      createNew: 'Criar Novo Sindicato',
      createDescription: 'Configure seu sindicato de loteria e convide jogadores para participar',
      basicInformation: 'Informações Básicas',
      syndicateName: 'Nome do Sindicato',
      syndicateNamePlaceholder: 'Digite o nome do sindicato',
      lottery: 'Loteria',
      selectLottery: 'Selecione uma loteria',
      description: 'Descrição',
      descriptionPlaceholder: 'Descreva sua estratégia e objetivos do sindicato',
      
      syndicateConfiguration: 'Configuração do Sindicato',
      riskFinancialSettings: 'Configurações de Risco e Financeiras',
      riskTolerance: 'Tolerância ao Risco',
      financialEffort: 'Esforço Financeiro',
      
      syndicateSummary: 'Resumo do Sindicato',
      entryFee: 'Taxa de Entrada',
      maxParticipants: 'Máx. Participantes',
      draws: 'Sorteios',
      maxEntries: 'Máx. Entradas',
      
      saveAsDraft: 'Salvar como Rascunho',
      createSyndicate: 'Criar Sindicato'
    },
    
    // Tier System
    tiers: {
      currentTier: 'Nível Atual',
      totalWinnings: 'Ganhos Totais',
      syndicatesJoined: 'Sindicatos Participados',
      activeSyndicates: 'Sindicatos Ativos',
      progressTo: 'Progresso para',
      remaining: 'restante',
      complete: 'completo',
      currentBenefits: 'Seus Benefícios Atuais:',
      tierSystemOverview: 'Visão Geral do Sistema de Níveis',
      tierSystemDescription: 'Desbloqueie novos benefícios e acesso exclusivo a sindicatos conforme alcança marcos de ganhos',
      moreBenefits: 'mais benefícios',
      current: 'Atual',
      
      // Tier Names
      starter: 'Iniciante',
      explorer: 'Explorador',
      adventurer: 'Aventureiro',
      specialist: 'Especialista',
      expert: 'Especialista',
      master: 'Mestre',
      elite: 'Elite',
      champion: 'Campeão',
      legend: 'Lenda'
    },
    
    // Common
    common: {
      loading: 'Carregando...',
      error: 'Erro',
      success: 'Sucesso',
      cancel: 'Cancelar',
      save: 'Salvar',
      edit: 'Editar',
      delete: 'Excluir',
      confirm: 'Confirmar',
      back: 'Voltar',
      next: 'Próximo',
      previous: 'Anterior',
      close: 'Fechar',
      search: 'Buscar',
      filter: 'Filtrar',
      sort: 'Ordenar',
      refresh: 'Atualizar'
    }
  },
  
  es: {
    // Navigation
    nav: {
      home: 'Inicio',
      chooseSyndicate: 'Elegir Sindicato',
      createSyndicate: 'Crear Sindicato',
      forum: 'Foro',
      members: 'Miembros',
      admin: 'Admin',
      login: 'Iniciar Sesión',
      register: 'Registrarse',
      logout: 'Cerrar Sesión',
      profile: 'Perfil'
    },
    
    // Landing Page
    landing: {
      heroTitle: 'Únete a los Sindicatos de Lotería Más Emocionantes del Mundo',
      heroSubtitle: 'Combina tus recursos con jugadores de todo el mundo en 9 loterías internacionales. Aumenta tus posibilidades, gestiona tu riesgo y desbloquea beneficios exclusivos.',
      browseSyndicates: 'Explorar Sindicatos',
      createSyndicate: 'Crear Sindicato',
      
      // Syndicate Types
      syndicateTypes: 'Tipos de Sindicato y Gestión de Riesgo',
      syndicateTypesSubtitle: 'Elige el tipo de sindicato perfecto y nivel de riesgo para tu estilo de juego',
      
      standardSyndicate: 'Sindicatos Estándar',
      standardDescription: 'Perfecto para jugadores regulares',
      standardFeatures: [
        '10 participaciones del 10% cada una',
        'Duración de 8 sorteos consecutivos',
        'Hasta 333 combinaciones diferentes',
        'Inversión menor, participación constante'
      ],
      
      superSyndicate: 'Super Sindicatos',
      superDescription: 'Para entusiastas serios de la lotería',
      superFeatures: [
        '100 participaciones del 1% cada una',
        'Duración de 4 sorteos consecutivos',
        'Hasta 999 combinaciones diferentes',
        'Inversión mayor, cobertura máxima'
      ],
      
      // Risk Levels
      cautious: 'Cauteloso',
      cautiousDescription: 'Enfoque estable con participación consistente',
      ambitious: 'Ambicioso',
      ambitiousDescription: 'Riesgo equilibrado con buen potencial de retorno',
      audacious: 'Audaz',
      audaciousDescription: 'Riesgo máximo para recompensas máximas',
      
      // Financial Effort
      minimum: 'Mínimo',
      minimumDescription: 'Inversión básica para jugadores casuales',
      medium: 'Medio',
      mediumDescription: 'Inversión moderada para jugadores regulares',
      maximum: 'Máximo',
      maximumDescription: 'Inversión premium para jugadores serios',
      
      // Tier System
      tierSystem: 'Sistema de 9 Niveles',
      tierSystemSubtitle: 'Desbloquea beneficios exclusivos al alcanzar hitos de ganancias',
      
      // Community Stats
      communityStats: 'Comunidad y Estadísticas',
      communityStatsSubtitle: 'Únete a miles de jugadores de todo el mundo en nuestros sindicatos de lotería',
      activePlayers: 'Jugadores Activos',
      activeSyndicates: 'Sindicatos Activos',
      totalWinnings: 'Ganancias Totales',
      internationalLotteries: 'Loterías Internacionales',
      
      // Available Lotteries
      availableLotteries: 'Loterías Disponibles',
      availableLotteriesSubtitle: 'Juega en 9 loterías internacionales con nuestro sistema de sindicatos',
      joinSyndicatesFor: 'Únete a sindicatos de esta lotería y aumenta tus posibilidades de ganar',
      
      // Call to Action
      readyToWin: '¿Listo para Empezar a Ganar?',
      readyToWinSubtitle: '¡Únete a los Sindicatos José Mil-Lotto hoy y forma parte de la comunidad de lotería más emocionante del mundo! Tu próxima gran victoria podría estar a solo un sindicato de distancia.',
      joinNowFree: '¡Únete Ahora - Es Gratis!'
    },
    
    // Authentication
    auth: {
      login: 'Iniciar Sesión',
      register: 'Registrarse',
      firstName: 'Nombre',
      lastName: 'Apellido',
      username: 'Nombre de Usuario',
      email: 'Email',
      password: 'Contraseña',
      confirmPassword: 'Confirmar Contraseña',
      termsAndConditions: 'Acepto los Términos y Condiciones',
      createAccount: 'Crear Cuenta',
      signIn: 'Iniciar Sesión',
      forgotPassword: '¿Olvidaste tu contraseña?',
      alreadyHaveAccount: '¿Ya tienes una cuenta?',
      dontHaveAccount: '¿No tienes una cuenta?',
      socialLogin: 'O continúa con',
      google: 'Google',
      facebook: 'Facebook',
      linkedin: 'LinkedIn'
    },
    
    // Syndicate Creation
    syndicate: {
      createNew: 'Crear Nuevo Sindicato',
      createDescription: 'Configura tu sindicato de lotería e invita jugadores a unirse',
      basicInformation: 'Información Básica',
      syndicateName: 'Nombre del Sindicato',
      syndicateNamePlaceholder: 'Ingresa el nombre del sindicato',
      lottery: 'Lotería',
      selectLottery: 'Selecciona una lotería',
      description: 'Descripción',
      descriptionPlaceholder: 'Describe tu estrategia y objetivos del sindicato',
      
      syndicateConfiguration: 'Configuración del Sindicato',
      riskFinancialSettings: 'Configuraciones de Riesgo y Financieras',
      riskTolerance: 'Tolerancia al Riesgo',
      financialEffort: 'Esfuerzo Financiero',
      
      syndicateSummary: 'Resumen del Sindicato',
      entryFee: 'Cuota de Entrada',
      maxParticipants: 'Máx. Participantes',
      draws: 'Sorteos',
      maxEntries: 'Máx. Entradas',
      
      saveAsDraft: 'Guardar como Borrador',
      createSyndicate: 'Crear Sindicato'
    },
    
    // Tier System
    tiers: {
      currentTier: 'Nivel Actual',
      totalWinnings: 'Ganancias Totales',
      syndicatesJoined: 'Sindicatos Unidos',
      activeSyndicates: 'Sindicatos Activos',
      progressTo: 'Progreso hacia',
      remaining: 'restante',
      complete: 'completo',
      currentBenefits: 'Tus Beneficios Actuales:',
      tierSystemOverview: 'Resumen del Sistema de Niveles',
      tierSystemDescription: 'Desbloquea nuevos beneficios y acceso exclusivo a sindicatos al alcanzar hitos de ganancias',
      moreBenefits: 'más beneficios',
      current: 'Actual',
      
      // Tier Names
      starter: 'Principiante',
      explorer: 'Explorador',
      adventurer: 'Aventurero',
      specialist: 'Especialista',
      expert: 'Experto',
      master: 'Maestro',
      elite: 'Elite',
      champion: 'Campeón',
      legend: 'Leyenda'
    },
    
    // Common
    common: {
      loading: 'Cargando...',
      error: 'Error',
      success: 'Éxito',
      cancel: 'Cancelar',
      save: 'Guardar',
      edit: 'Editar',
      delete: 'Eliminar',
      confirm: 'Confirmar',
      back: 'Atrás',
      next: 'Siguiente',
      previous: 'Anterior',
      close: 'Cerrar',
      search: 'Buscar',
      filter: 'Filtrar',
      sort: 'Ordenar',
      refresh: 'Actualizar'
    }
  }
};

// Translation Provider Component
export const TranslationProvider = ({ children }) => {
  const [currentLanguage, setCurrentLanguage] = useState('en');

  // Load language from localStorage on mount
  useEffect(() => {
    const savedLanguage = localStorage.getItem('language');
    if (savedLanguage && translations[savedLanguage]) {
      setCurrentLanguage(savedLanguage);
    }
  }, []);

  // Save language to localStorage when changed
  const changeLanguage = (language) => {
    if (translations[language]) {
      setCurrentLanguage(language);
      localStorage.setItem('language', language);
    }
  };

  // Get translation function
  const t = (key) => {
    const keys = key.split('.');
    let value = translations[currentLanguage];
    
    for (const k of keys) {
      if (value && typeof value === 'object' && k in value) {
        value = value[k];
      } else {
        // Fallback to English if translation not found
        value = translations.en;
        for (const fallbackKey of keys) {
          if (value && typeof value === 'object' && fallbackKey in value) {
            value = value[fallbackKey];
          } else {
            return key; // Return key if no translation found
          }
        }
        break;
      }
    }
    
    return typeof value === 'string' ? value : key;
  };

  // Get array translation function
  const tArray = (key) => {
    const keys = key.split('.');
    let value = translations[currentLanguage];
    
    for (const k of keys) {
      if (value && typeof value === 'object' && k in value) {
        value = value[k];
      } else {
        // Fallback to English if translation not found
        value = translations.en;
        for (const fallbackKey of keys) {
          if (value && typeof value === 'object' && fallbackKey in value) {
            value = value[fallbackKey];
          } else {
            return []; // Return empty array if no translation found
          }
        }
        break;
      }
    }
    
    return Array.isArray(value) ? value : [];
  };

  const value = {
    currentLanguage,
    changeLanguage,
    t,
    tArray,
    availableLanguages: {
      en: 'English',
      pt: 'Português',
      es: 'Español'
    }
  };

  return (
    <TranslationContext.Provider value={value}>
      {children}
    </TranslationContext.Provider>
  );
};

// Hook to use translation
export const useTranslation = () => {
  const context = useContext(TranslationContext);
  if (!context) {
    throw new Error('useTranslation must be used within a TranslationProvider');
  }
  return context;
};

// Language Selector Component
export const LanguageSelector = ({ className = '' }) => {
  const { currentLanguage, changeLanguage, availableLanguages } = useTranslation();

  return (
    <select 
      value={currentLanguage} 
      onChange={(e) => changeLanguage(e.target.value)}
      className={`border rounded px-3 py-1 ${className}`}
    >
      {Object.entries(availableLanguages).map(([code, name]) => (
        <option key={code} value={code}>{name}</option>
      ))}
    </select>
  );
};

export default { TranslationProvider, useTranslation, LanguageSelector };

