from flask import Blueprint, request, jsonify
from src.models.user import db, Tier, User, Syndicate, Share, Entry, Lottery
from sqlalchemy import func, desc

stats_bp = Blueprint('stats', __name__)

@stats_bp.route('/tiers', methods=['GET'])
def get_tiers():
    """Get all tiers"""
    try:
        tiers = Tier.query.order_by(Tier.level).all()
        return jsonify({
            'success': True,
            'data': [tier.to_dict() for tier in tiers]
        })
    except Exception as e:
        return jsonify({
            'success': False,
            'error': str(e)
        }), 500

@stats_bp.route('/tiers/<int:tier_id>', methods=['GET'])
def get_tier(tier_id):
    """Get a specific tier by ID"""
    try:
        tier = Tier.query.get_or_404(tier_id)
        return jsonify({
            'success': True,
            'data': tier.to_dict()
        })
    except Exception as e:
        return jsonify({
            'success': False,
            'error': str(e)
        }), 500

@stats_bp.route('/stats/dashboard', methods=['GET'])
def get_dashboard_stats():
    """Get dashboard statistics"""
    try:
        # User statistics
        total_users = User.query.filter_by(is_active=True).count()
        verified_users = User.query.filter_by(is_active=True, is_verified=True).count()
        
        # Syndicate statistics
        total_syndicates = Syndicate.query.count()
        active_syndicates = Syndicate.query.filter_by(status='Active').count()
        pending_syndicates = Syndicate.query.filter_by(status='Pending').count()
        
        # Share statistics
        total_shares = Share.query.count()
        mil_lotto_shares = Share.query.filter_by(is_mil_lotto_share=True).count()
        
        # Winnings statistics
        total_winnings = db.session.query(func.sum(Entry.winnings)).scalar() or 0
        total_entries = Entry.query.count()
        winning_entries = Entry.query.filter(Entry.winnings > 0).count()
        
        # Lottery statistics
        active_lotteries = Lottery.query.filter_by(is_active=True).count()
        
        # Recent activity
        recent_syndicates = Syndicate.query.order_by(desc(Syndicate.created_at)).limit(5).all()
        recent_wins = Entry.query.filter(Entry.winnings > 0).order_by(desc(Entry.updated_at)).limit(5).all()
        
        return jsonify({
            'success': True,
            'data': {
                'users': {
                    'total': total_users,
                    'verified': verified_users,
                    'verification_rate': round((verified_users / total_users * 100) if total_users > 0 else 0, 2)
                },
                'syndicates': {
                    'total': total_syndicates,
                    'active': active_syndicates,
                    'pending': pending_syndicates
                },
                'shares': {
                    'total': total_shares,
                    'mil_lotto_shares': mil_lotto_shares,
                    'user_shares': total_shares - mil_lotto_shares
                },
                'winnings': {
                    'total_amount': float(total_winnings),
                    'total_entries': total_entries,
                    'winning_entries': winning_entries,
                    'win_rate': round((winning_entries / total_entries * 100) if total_entries > 0 else 0, 2)
                },
                'lotteries': {
                    'active': active_lotteries
                },
                'recent_activity': {
                    'syndicates': [s.to_dict() for s in recent_syndicates],
                    'wins': [e.to_dict() for e in recent_wins]
                }
            }
        })
    except Exception as e:
        return jsonify({
            'success': False,
            'error': str(e)
        }), 500

@stats_bp.route('/stats/user/<int:user_id>', methods=['GET'])
def get_user_stats(user_id):
    """Get statistics for a specific user"""
    try:
        user = User.query.get_or_404(user_id)
        
        # User's syndicates
        user_shares = Share.query.filter_by(user_id=user_id).all()
        syndicate_ids = [share.syndicate_id for share in user_shares]
        user_syndicates = Syndicate.query.filter(Syndicate.id.in_(syndicate_ids)).all()
        
        # User's winnings
        user_entries = db.session.query(Entry).join(Share).filter(
            Share.user_id == user_id,
            Entry.syndicate_id == Share.syndicate_id
        ).all()
        
        total_winnings = sum(entry.winnings * (share.percentage / 100) 
                           for entry in user_entries 
                           for share in user_shares 
                           if entry.syndicate_id == share.syndicate_id)
        
        # Created syndicates
        created_syndicates = Syndicate.query.filter_by(creator_id=user_id).all()
        
        return jsonify({
            'success': True,
            'data': {
                'user': user.to_dict(),
                'syndicates': {
                    'joined': len(user_syndicates),
                    'created': len(created_syndicates),
                    'total_shares': len(user_shares)
                },
                'winnings': {
                    'total': float(total_winnings),
                    'entries': len(user_entries)
                },
                'tier': user.current_tier.to_dict() if user.current_tier else None
            }
        })
    except Exception as e:
        return jsonify({
            'success': False,
            'error': str(e)
        }), 500

@stats_bp.route('/stats/lottery/<int:lottery_id>', methods=['GET'])
def get_lottery_stats(lottery_id):
    """Get statistics for a specific lottery"""
    try:
        lottery = Lottery.query.get_or_404(lottery_id)
        
        # Lottery syndicates
        lottery_syndicates = Syndicate.query.filter_by(lottery_id=lottery_id).all()
        active_syndicates = [s for s in lottery_syndicates if s.status.value == 'Active']
        
        # Lottery entries and winnings
        syndicate_ids = [s.id for s in lottery_syndicates]
        lottery_entries = Entry.query.filter(Entry.syndicate_id.in_(syndicate_ids)).all()
        total_winnings = sum(entry.winnings for entry in lottery_entries)
        winning_entries = [e for e in lottery_entries if e.winnings > 0]
        
        return jsonify({
            'success': True,
            'data': {
                'lottery': lottery.to_dict(),
                'syndicates': {
                    'total': len(lottery_syndicates),
                    'active': len(active_syndicates)
                },
                'entries': {
                    'total': len(lottery_entries),
                    'winning': len(winning_entries)
                },
                'winnings': {
                    'total': float(total_winnings),
                    'average_per_entry': float(total_winnings / len(lottery_entries)) if lottery_entries else 0
                }
            }
        })
    except Exception as e:
        return jsonify({
            'success': False,
            'error': str(e)
        }), 500

