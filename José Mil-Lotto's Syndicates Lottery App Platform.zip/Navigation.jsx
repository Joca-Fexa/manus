import React, { useState } from 'react';
import { Button } from '@/components/ui/button';
import { Sheet, SheetContent, SheetTrigger } from '@/components/ui/sheet';
import { Menu, X } from 'lucide-react';

// Mobile Navigation Component
export const MobileNavigation = () => {
  const [isOpen, setIsOpen] = useState(false);

  const navigationItems = [
    { label: 'Choose Syndicate', href: '#' },
    { label: 'Create Syndicate', href: '#' },
    { label: 'Forum', href: '#' },
    { label: 'Members', href: '#' },
    { label: 'Admin', href: '#' }
  ];

  return (
    <Sheet open={isOpen} onOpenChange={setIsOpen}>
      <SheetTrigger asChild>
        <Button variant="ghost" size="sm" className="md:hidden">
          <Menu className="h-6 w-6" />
        </Button>
      </SheetTrigger>
      <SheetContent side="right" className="w-[300px] sm:w-[400px]">
        <div className="flex flex-col space-y-4 mt-6">
          <div className="flex items-center justify-between">
            <h2 className="text-lg font-semibold">Menu</h2>
            <Button variant="ghost" size="sm" onClick={() => setIsOpen(false)}>
              <X className="h-6 w-6" />
            </Button>
          </div>
          
          <nav className="flex flex-col space-y-3">
            {navigationItems.map((item, index) => (
              <a
                key={index}
                href={item.href}
                className="text-gray-900 hover:text-primary px-3 py-2 rounded-md text-base font-medium border-b border-gray-100"
                onClick={() => setIsOpen(false)}
              >
                {item.label}
              </a>
            ))}
          </nav>
          
          <div className="pt-4 border-t border-gray-200">
            <div className="space-y-3">
              <div>
                <label className="text-sm font-medium text-gray-700 block mb-2">Language</label>
                <select className="w-full text-sm border rounded-md px-3 py-2">
                  <option value="en">English</option>
                  <option value="pt">Português</option>
                  <option value="es">Español</option>
                </select>
              </div>
              
              <div className="flex flex-col space-y-2">
                <Button variant="outline" className="w-full">Login</Button>
                <Button className="w-full">Register</Button>
              </div>
            </div>
          </div>
        </div>
      </SheetContent>
    </Sheet>
  );
};

// Responsive Header Component
export const ResponsiveHeader = () => {
  return (
    <header className="bg-white shadow-sm border-b">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="flex justify-between items-center h-16">
          <div className="flex items-center">
            <div className="flex-shrink-0">
              <h1 className="text-xl md:text-2xl font-bold text-primary">
                José Mil-Lotto's Syndicates
              </h1>
            </div>
          </div>
          
          {/* Desktop Navigation */}
          <nav className="hidden md:block">
            <div className="ml-10 flex items-baseline space-x-4">
              <a href="#" className="text-gray-900 hover:text-primary px-3 py-2 rounded-md text-sm font-medium">
                Choose Syndicate
              </a>
              <a href="#" className="text-gray-900 hover:text-primary px-3 py-2 rounded-md text-sm font-medium">
                Create Syndicate
              </a>
              <a href="#" className="text-gray-900 hover:text-primary px-3 py-2 rounded-md text-sm font-medium">
                Forum
              </a>
              <a href="#" className="text-gray-900 hover:text-primary px-3 py-2 rounded-md text-sm font-medium">
                Members
              </a>
              <a href="#" className="text-gray-900 hover:text-primary px-3 py-2 rounded-md text-sm font-medium">
                Admin
              </a>
            </div>
          </nav>
          
          {/* Desktop Actions */}
          <div className="hidden md:flex items-center space-x-4">
            <select className="text-sm border rounded-md px-2 py-1">
              <option value="en">English</option>
              <option value="pt">Português</option>
              <option value="es">Español</option>
            </select>
            <Button variant="outline" size="sm">Login</Button>
            <Button size="sm">Register</Button>
          </div>
          
          {/* Mobile Navigation */}
          <MobileNavigation />
        </div>
      </div>
    </header>
  );
};

// Breadcrumb Component
export const Breadcrumb = ({ items }) => {
  return (
    <nav className="flex" aria-label="Breadcrumb">
      <ol className="inline-flex items-center space-x-1 md:space-x-3">
        {items.map((item, index) => (
          <li key={index} className="inline-flex items-center">
            {index > 0 && (
              <svg className="w-6 h-6 text-gray-400" fill="currentColor" viewBox="0 0 20 20">
                <path fillRule="evenodd" d="M7.293 14.707a1 1 0 010-1.414L10.586 10 7.293 6.707a1 1 0 011.414-1.414l4 4a1 1 0 010 1.414l-4 4a1 1 0 01-1.414 0z" clipRule="evenodd"></path>
              </svg>
            )}
            {item.href ? (
              <a href={item.href} className="ml-1 text-sm font-medium text-gray-700 hover:text-primary md:ml-2">
                {item.label}
              </a>
            ) : (
              <span className="ml-1 text-sm font-medium text-gray-500 md:ml-2">
                {item.label}
              </span>
            )}
          </li>
        ))}
      </ol>
    </nav>
  );
};

// Page Container Component
export const PageContainer = ({ children, title, breadcrumb }) => {
  return (
    <div className="min-h-screen bg-gray-50">
      <ResponsiveHeader />
      
      <main className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
        {breadcrumb && (
          <div className="mb-6">
            <Breadcrumb items={breadcrumb} />
          </div>
        )}
        
        {title && (
          <div className="mb-8">
            <h1 className="text-3xl font-bold text-gray-900">{title}</h1>
          </div>
        )}
        
        {children}
      </main>
    </div>
  );
};

