import React, { useState } from 'react';
import { Button } from '@/components/ui/button';
import { Badge } from '@/components/ui/badge';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
import { Users, Target, DollarSign, Calendar, Trophy, Star, Globe, TrendingUp, Award, Crown } from 'lucide-react';
import { AuthProvider } from './contexts/AuthContext';
import { TranslationProvider, useTranslation, LanguageSelector } from './contexts/TranslationContext';
import { RegistrationForm, LoginForm } from './components/AuthForms';
import { SyndicateCreationForm, SyndicateManagement } from './components/SyndicateComponents';

function AppContent() {
  const [currentPage, setCurrentPage] = useState('home');
  const { t, tArray } = useTranslation();

  const lotteries = [
    { id: 1, name: 'Norway Lotto', country: 'Norway', country_flag: '🇳🇴', format: '7 from 34 numbers' },
    { id: 2, name: 'Sweden Lotto', country: 'Sweden', country_flag: '🇸🇪', format: '7 from 35 numbers' },
    { id: 3, name: 'Denmark Lotto', country: 'Denmark', country_flag: '🇩🇰', format: '7 from 36 numbers' },
    { id: 4, name: 'Swiss Lotto', country: 'Switzerland', country_flag: '🇨🇭', format: '6 from 42 numbers' },
    { id: 5, name: 'Japan Lotto', country: 'Japan', country_flag: '🇯🇵', format: '6 from 43 numbers' },
    { id: 6, name: 'Irish Lottery', country: 'Ireland', country_flag: '🇮🇪', format: '6 from 47 numbers' },
    { id: 7, name: 'Spain Loteria', country: 'Spain', country_flag: '🇪🇸', format: '6 from 49 numbers' },
    { id: 8, name: 'New York Lotto', country: 'USA', country_flag: '🇺🇸', format: '6 from 59 numbers' },
    { id: 9, name: 'Brazil Mega Sena', country: 'Brazil', country_flag: '🇧🇷', format: '6 from 60 numbers' }
  ];

  const handleCreateSyndicate = async (formData) => {
    try {
      const response = await fetch('http://localhost:5000/api/syndicates', {
        method: 'POST',
        credentials: 'include',
        headers: {
          'Content-Type': 'application/json',
        },
        body: JSON.stringify({
          name: formData.name,
          description: formData.description,
          lottery_id: parseInt(formData.lottery_id),
          syndicate_type: formData.syndicate_type,
          risk_level: formData.risk_tolerance,
          financial_effort: formData.financial_effort,
          start_date: new Date().toISOString().split('T')[0],
          creator_id: 1
        }),
      });

      const data = await response.json();
      
      if (data.success) {
        alert(t('common.success'));
        setCurrentPage('syndicates');
      } else {
        alert(`${t('common.error')}: ${data.error || data.message}`);
      }
    } catch (error) {
      console.error('Error creating syndicate:', error);
      alert(t('common.error'));
    }
  };

  const renderPage = () => {
    switch (currentPage) {
      case 'register':
        return <RegistrationForm onSubmit={() => {}} />;
      case 'login':
        return <LoginForm onSubmit={() => {}} />;
      case 'create-syndicate':
        return <SyndicateCreationForm onSubmit={handleCreateSyndicate} lotteries={lotteries} />;
      case 'syndicates':
        return <SyndicateManagement syndicates={[]} onJoinSyndicate={() => {}} onLeaveSyndicate={() => {}} />;
      default:
        return <LandingPage />;
    }
  };

  const LandingPage = () => (
    <div className="min-h-screen bg-gray-50">
      {/* Hero Section */}
      <section className="bg-gradient-to-br from-blue-600 via-purple-600 to-blue-800 text-white py-20">
        <div className="container mx-auto px-6 text-center">
          <h1 className="text-5xl md:text-6xl font-bold mb-6">
            {t('landing.heroTitle')}
          </h1>
          <p className="text-xl md:text-2xl mb-8 max-w-3xl mx-auto">
            {t('landing.heroSubtitle')}
          </p>
          <div className="flex flex-col sm:flex-row gap-4 justify-center">
            <Button 
              size="lg" 
              className="bg-white text-blue-600 hover:bg-gray-100"
              onClick={() => setCurrentPage('syndicates')}
            >
              {t('landing.browseSyndicates')}
            </Button>
            <Button 
              size="lg" 
              variant="outline" 
              className="border-white text-white hover:bg-white hover:text-blue-600"
              onClick={() => setCurrentPage('create-syndicate')}
            >
              {t('landing.createSyndicate')}
            </Button>
          </div>
        </div>
      </section>

      {/* Syndicate Types Section */}
      <section className="py-16">
        <div className="container mx-auto px-6">
          <div className="text-center mb-12">
            <h2 className="text-3xl md:text-4xl font-bold text-gray-900 mb-4">
              {t('landing.syndicateTypes')}
            </h2>
            <p className="text-xl text-gray-600">
              {t('landing.syndicateTypesSubtitle')}
            </p>
          </div>

          <div className="grid md:grid-cols-2 gap-8 mb-12">
            {/* Standard Syndicates */}
            <Card className="hover:shadow-lg transition-shadow">
              <CardHeader>
                <div className="flex items-center gap-3">
                  <Users className="h-8 w-8 text-blue-600" />
                  <div>
                    <CardTitle className="text-xl">{t('landing.standardSyndicate')}</CardTitle>
                    <CardDescription>{t('landing.standardDescription')}</CardDescription>
                  </div>
                </div>
              </CardHeader>
              <CardContent>
                <ul className="space-y-2 text-gray-700">
                  {tArray('landing.standardFeatures').map((feature, index) => (
                    <li key={index}>• {feature}</li>
                  ))}
                </ul>
              </CardContent>
            </Card>

            {/* Super Syndicates */}
            <Card className="hover:shadow-lg transition-shadow">
              <CardHeader>
                <div className="flex items-center gap-3">
                  <Trophy className="h-8 w-8 text-purple-600" />
                  <div>
                    <CardTitle className="text-xl">{t('landing.superSyndicate')}</CardTitle>
                    <CardDescription>{t('landing.superDescription')}</CardDescription>
                  </div>
                </div>
              </CardHeader>
              <CardContent>
                <ul className="space-y-2 text-gray-700">
                  {tArray('landing.superFeatures').map((feature, index) => (
                    <li key={index}>• {feature}</li>
                  ))}
                </ul>
              </CardContent>
            </Card>
          </div>

          {/* Risk Tolerance Levels */}
          <div className="grid md:grid-cols-3 gap-6 mb-8">
            <Card className="text-center">
              <CardContent className="pt-6">
                <Target className="h-12 w-12 text-green-600 mx-auto mb-4" />
                <h3 className="text-xl font-semibold mb-2">{t('landing.cautious')}</h3>
                <Badge className="bg-green-100 text-green-800 mb-3">Conservative</Badge>
                <p className="text-gray-600">{t('landing.cautiousDescription')}</p>
              </CardContent>
            </Card>

            <Card className="text-center">
              <CardContent className="pt-6">
                <TrendingUp className="h-12 w-12 text-yellow-600 mx-auto mb-4" />
                <h3 className="text-xl font-semibold mb-2">{t('landing.ambitious')}</h3>
                <Badge className="bg-yellow-100 text-yellow-800 mb-3">Balanced</Badge>
                <p className="text-gray-600">{t('landing.ambitiousDescription')}</p>
              </CardContent>
            </Card>

            <Card className="text-center">
              <CardContent className="pt-6">
                <Award className="h-12 w-12 text-red-600 mx-auto mb-4" />
                <h3 className="text-xl font-semibold mb-2">{t('landing.audacious')}</h3>
                <Badge className="bg-red-100 text-red-800 mb-3">High Risk</Badge>
                <p className="text-gray-600">{t('landing.audaciousDescription')}</p>
              </CardContent>
            </Card>
          </div>

          {/* Financial Effort Levels */}
          <div className="grid md:grid-cols-3 gap-6">
            <Card className="text-center">
              <CardContent className="pt-6">
                <DollarSign className="h-12 w-12 text-blue-600 mx-auto mb-4" />
                <h3 className="text-xl font-semibold mb-2">{t('landing.minimum')}</h3>
                <Badge variant="outline" className="mb-3">£5-15</Badge>
                <p className="text-gray-600">{t('landing.minimumDescription')}</p>
              </CardContent>
            </Card>

            <Card className="text-center">
              <CardContent className="pt-6">
                <DollarSign className="h-12 w-12 text-green-600 mx-auto mb-4" />
                <h3 className="text-xl font-semibold mb-2">{t('landing.medium')}</h3>
                <Badge variant="outline" className="mb-3">£15-35</Badge>
                <p className="text-gray-600">{t('landing.mediumDescription')}</p>
              </CardContent>
            </Card>

            <Card className="text-center">
              <CardContent className="pt-6">
                <DollarSign className="h-12 w-12 text-purple-600 mx-auto mb-4" />
                <h3 className="text-xl font-semibold mb-2">{t('landing.maximum')}</h3>
                <Badge variant="outline" className="mb-3">£35-75</Badge>
                <p className="text-gray-600">{t('landing.maximumDescription')}</p>
              </CardContent>
            </Card>
          </div>
        </div>
      </section>

      {/* 9-Tier System */}
      <section className="py-16 bg-white">
        <div className="container mx-auto px-6">
          <div className="text-center mb-12">
            <h2 className="text-3xl md:text-4xl font-bold text-gray-900 mb-4">
              {t('landing.tierSystem')}
            </h2>
            <p className="text-xl text-gray-600">
              {t('landing.tierSystemSubtitle')}
            </p>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
            {[
              { tier: 1, name: t('tiers.starter'), threshold: '£0', color: 'bg-gray-100 text-gray-800', icon: Star },
              { tier: 2, name: t('tiers.explorer'), threshold: '£500', color: 'bg-blue-100 text-blue-800', icon: Target },
              { tier: 3, name: t('tiers.adventurer'), threshold: '£1,000', color: 'bg-green-100 text-green-800', icon: TrendingUp },
              { tier: 4, name: t('tiers.specialist'), threshold: '£2,500', color: 'bg-yellow-100 text-yellow-800', icon: Award },
              { tier: 5, name: t('tiers.expert'), threshold: '£5,000', color: 'bg-orange-100 text-orange-800', icon: Trophy },
              { tier: 6, name: t('tiers.master'), threshold: '£10,000', color: 'bg-red-100 text-red-800', icon: Crown },
              { tier: 7, name: t('tiers.elite'), threshold: '£25,000', color: 'bg-purple-100 text-purple-800', icon: Star },
              { tier: 8, name: t('tiers.champion'), threshold: '£50,000', color: 'bg-indigo-100 text-indigo-800', icon: Award },
              { tier: 9, name: t('tiers.legend'), threshold: '£100,000', color: 'bg-pink-100 text-pink-800', icon: Crown }
            ].map((tier) => {
              const IconComponent = tier.icon;
              return (
                <Card key={tier.tier} className="text-center hover:shadow-lg transition-shadow">
                  <CardContent className="pt-6">
                    <div className="flex justify-center mb-4">
                      <div className={`p-3 rounded-full ${tier.color}`}>
                        <IconComponent className="h-6 w-6" />
                      </div>
                    </div>
                    <h3 className="text-lg font-semibold mb-2">Tier {tier.tier}: {tier.name}</h3>
                    <Badge className={tier.color}>{tier.threshold}+</Badge>
                    <p className="text-sm text-gray-600 mt-2">
                      {tier.tier === 1 ? 'Open to all players' : `Unlock after ${tier.threshold} winnings`}
                    </p>
                  </CardContent>
                </Card>
              );
            })}
          </div>
        </div>
      </section>

      {/* Community Statistics */}
      <section className="py-16 bg-gray-50">
        <div className="container mx-auto px-6">
          <div className="text-center mb-12">
            <h2 className="text-3xl md:text-4xl font-bold text-gray-900 mb-4">
              {t('landing.communityStats')}
            </h2>
            <p className="text-xl text-gray-600">
              {t('landing.communityStatsSubtitle')}
            </p>
          </div>

          <div className="grid grid-cols-2 md:grid-cols-4 gap-6">
            <Card className="text-center">
              <CardContent className="pt-6">
                <div className="text-3xl font-bold text-blue-600 mb-2">15,847</div>
                <div className="text-gray-600">{t('landing.activePlayers')}</div>
              </CardContent>
            </Card>

            <Card className="text-center">
              <CardContent className="pt-6">
                <div className="text-3xl font-bold text-green-600 mb-2">2,341</div>
                <div className="text-gray-600">{t('landing.activeSyndicates')}</div>
              </CardContent>
            </Card>

            <Card className="text-center">
              <CardContent className="pt-6">
                <div className="text-3xl font-bold text-purple-600 mb-2">£2.8M</div>
                <div className="text-gray-600">{t('landing.totalWinnings')}</div>
              </CardContent>
            </Card>

            <Card className="text-center">
              <CardContent className="pt-6">
                <div className="text-3xl font-bold text-orange-600 mb-2">9</div>
                <div className="text-gray-600">{t('landing.internationalLotteries')}</div>
              </CardContent>
            </Card>
          </div>
        </div>
      </section>

      {/* Available Lotteries */}
      <section className="py-16 bg-white">
        <div className="container mx-auto px-6">
          <div className="text-center mb-12">
            <h2 className="text-3xl md:text-4xl font-bold text-gray-900 mb-4">
              {t('landing.availableLotteries')}
            </h2>
            <p className="text-xl text-gray-600">
              {t('landing.availableLotteriesSubtitle')}
            </p>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
            {lotteries.map((lottery) => (
              <Card key={lottery.id} className="hover:shadow-lg transition-shadow">
                <CardContent className="pt-6">
                  <div className="flex items-center gap-4 mb-4">
                    <span className="text-4xl">{lottery.country_flag}</span>
                    <div>
                      <h3 className="text-lg font-semibold">{lottery.name}</h3>
                      <p className="text-gray-600">{lottery.country}</p>
                    </div>
                  </div>
                  <Badge variant="outline" className="mb-3">{lottery.format}</Badge>
                  <p className="text-sm text-gray-600">
                    {t('landing.joinSyndicatesFor')}
                  </p>
                </CardContent>
              </Card>
            ))}
          </div>
        </div>
      </section>

      {/* Call to Action */}
      <section className="py-16 bg-gradient-to-r from-purple-600 to-blue-600 text-white">
        <div className="container mx-auto px-6 text-center">
          <h2 className="text-3xl md:text-4xl font-bold mb-4">
            {t('landing.readyToWin')}
          </h2>
          <p className="text-xl mb-8 max-w-2xl mx-auto">
            {t('landing.readyToWinSubtitle')}
          </p>
          <div className="flex flex-col sm:flex-row gap-4 justify-center">
            <Button 
              size="lg" 
              className="bg-white text-purple-600 hover:bg-gray-100"
              onClick={() => setCurrentPage('register')}
            >
              {t('landing.joinNowFree')}
            </Button>
            <Button 
              size="lg" 
              variant="outline" 
              className="border-white text-white hover:bg-white hover:text-purple-600"
              onClick={() => setCurrentPage('syndicates')}
            >
              {t('landing.browseSyndicates')}
            </Button>
          </div>
        </div>
      </section>

      {/* Footer */}
      <footer className="bg-gray-900 text-white py-12">
        <div className="container mx-auto px-6">
          <div className="grid md:grid-cols-4 gap-8">
            <div>
              <h3 className="text-lg font-semibold mb-4">José Mil-Lotto's Syndicates</h3>
              <p className="text-gray-400">
                The world's premier lottery syndicate platform, connecting players 
                across 9 international lotteries.
              </p>
            </div>
            
            <div>
              <h4 className="font-semibold mb-4">Quick Links</h4>
              <ul className="space-y-2 text-gray-400">
                <li><a href="#" className="hover:text-white">How It Works</a></li>
                <li><a href="#" className="hover:text-white">Syndicate Types</a></li>
                <li><a href="#" className="hover:text-white">Tier System</a></li>
                <li><a href="#" className="hover:text-white">FAQ</a></li>
              </ul>
            </div>
            
            <div>
              <h4 className="font-semibold mb-4">Support</h4>
              <ul className="space-y-2 text-gray-400">
                <li><a href="#" className="hover:text-white">Help Center</a></li>
                <li><a href="#" className="hover:text-white">Contact Us</a></li>
                <li><a href="#" className="hover:text-white">Terms & Conditions</a></li>
                <li><a href="#" className="hover:text-white">Privacy Policy</a></li>
              </ul>
            </div>
            
            <div>
              <h4 className="font-semibold mb-4">Follow Us</h4>
              <div className="flex space-x-4">
                <a href="#" className="text-gray-400 hover:text-white">Facebook</a>
                <a href="#" className="text-gray-400 hover:text-white">Twitter</a>
                <a href="#" className="text-gray-400 hover:text-white">Instagram</a>
              </div>
            </div>
          </div>
          
          <div className="border-t border-gray-800 mt-8 pt-8 text-center text-gray-400">
            <p>&copy; 2025 José Mil-Lotto's Syndicates. All rights reserved.</p>
          </div>
        </div>
      </footer>
    </div>
  );

  return (
    <div className="min-h-screen bg-gray-50">
      {/* Header */}
      <header className="bg-white shadow-sm border-b">
        <div className="container mx-auto px-6 py-4">
          <div className="flex items-center justify-between">
            <h1 
              className="text-2xl font-bold text-gray-900 cursor-pointer"
              onClick={() => setCurrentPage('home')}
            >
              José Mil-Lotto's Syndicates
            </h1>
            
            <nav className="hidden md:flex items-center space-x-6">
              <Button 
                variant="ghost" 
                onClick={() => setCurrentPage('syndicates')}
              >
                {t('nav.chooseSyndicate')}
              </Button>
              <Button 
                variant="ghost" 
                onClick={() => setCurrentPage('create-syndicate')}
              >
                {t('nav.createSyndicate')}
              </Button>
              <Button variant="ghost">{t('nav.forum')}</Button>
              
              <LanguageSelector />
              
              <Button 
                variant="outline"
                onClick={() => setCurrentPage('login')}
              >
                {t('nav.login')}
              </Button>
              <Button 
                onClick={() => setCurrentPage('register')}
              >
                {t('nav.register')}
              </Button>
            </nav>
          </div>
        </div>
      </header>

      {/* Main Content */}
      <main>
        {renderPage()}
      </main>
    </div>
  );
}

function App() {
  return (
    <TranslationProvider>
      <AuthProvider>
        <AppContent />
      </AuthProvider>
    </TranslationProvider>
  );
}

export default App;

