import React, { useState, useEffect } from 'react';
import { Button } from '@/components/ui/button';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';
import { Progress } from '@/components/ui/progress';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import { 
  Star, Target, TrendingUp, Award, Trophy, Crown, 
  Lock, Unlock, DollarSign, Users, Calendar, 
  CheckCircle, AlertCircle, Info 
} from 'lucide-react';

// Tier System Component
export const TierSystem = ({ userTier = 1, userWinnings = 0, userStats = {} }) => {
  const tiers = [
    { 
      level: 1, 
      name: 'Starter', 
      threshold: 0, 
      color: 'bg-gray-100 text-gray-800', 
      icon: Star,
      benefits: ['Access to all Standard syndicates', 'Basic community features', 'Entry-level lottery access'],
      description: 'Welcome to José Mil-Lotto\'s Syndicates! Start your lottery journey here.'
    },
    { 
      level: 2, 
      name: 'Explorer', 
      threshold: 500, 
      color: 'bg-blue-100 text-blue-800', 
      icon: Target,
      benefits: ['Access to Tier 2 syndicates', 'Enhanced statistics', 'Priority customer support'],
      description: 'You\'re exploring the possibilities! Unlock better syndicate opportunities.'
    },
    { 
      level: 3, 
      name: 'Adventurer', 
      threshold: 1000, 
      color: 'bg-green-100 text-green-800', 
      icon: TrendingUp,
      benefits: ['Access to Tier 3 syndicates', 'Advanced analytics', 'Exclusive lottery events'],
      description: 'Adventure awaits! Access to more exclusive syndicate opportunities.'
    },
    { 
      level: 4, 
      name: 'Specialist', 
      threshold: 2500, 
      color: 'bg-yellow-100 text-yellow-800', 
      icon: Award,
      benefits: ['Access to Tier 4 syndicates', 'Custom syndicate creation', 'VIP support'],
      description: 'You\'re becoming a specialist! Create your own premium syndicates.'
    },
    { 
      level: 5, 
      name: 'Expert', 
      threshold: 5000, 
      color: 'bg-orange-100 text-orange-800', 
      icon: Trophy,
      benefits: ['Access to Tier 5 syndicates', 'Syndicate management tools', 'Expert insights'],
      description: 'Expert level achieved! Manage multiple syndicates with advanced tools.'
    },
    { 
      level: 6, 
      name: 'Master', 
      threshold: 10000, 
      color: 'bg-red-100 text-red-800', 
      icon: Crown,
      benefits: ['Access to Tier 6 syndicates', 'Private syndicate rooms', 'Master privileges'],
      description: 'Master status! Access to the most exclusive syndicate opportunities.'
    },
    { 
      level: 7, 
      name: 'Elite', 
      threshold: 25000, 
      color: 'bg-purple-100 text-purple-800', 
      icon: Star,
      benefits: ['Access to Elite syndicates', 'Personal account manager', 'Elite events'],
      description: 'Elite member! Enjoy personalized service and exclusive events.'
    },
    { 
      level: 8, 
      name: 'Champion', 
      threshold: 50000, 
      color: 'bg-indigo-100 text-indigo-800', 
      icon: Award,
      benefits: ['Champion syndicate access', 'Investment advisory', 'Champion rewards'],
      description: 'Champion level! Access to the highest tier syndicate investments.'
    },
    { 
      level: 9, 
      name: 'Legend', 
      threshold: 100000, 
      color: 'bg-pink-100 text-pink-800', 
      icon: Crown,
      benefits: ['Legendary syndicate access', 'Unlimited privileges', 'Legend status'],
      description: 'Legendary status! The ultimate lottery syndicate experience.'
    }
  ];

  const currentTier = tiers.find(tier => tier.level === userTier) || tiers[0];
  const nextTier = tiers.find(tier => tier.level === userTier + 1);
  
  const progressToNext = nextTier 
    ? Math.min(100, (userWinnings / nextTier.threshold) * 100)
    : 100;

  const remainingToNext = nextTier 
    ? Math.max(0, nextTier.threshold - userWinnings)
    : 0;

  return (
    <div className="space-y-6">
      {/* Current Tier Status */}
      <Card className="bg-gradient-to-r from-blue-50 to-purple-50">
        <CardHeader>
          <div className="flex items-center justify-between">
            <div className="flex items-center gap-4">
              <div className={`p-4 rounded-full ${currentTier.color}`}>
                <currentTier.icon className="h-8 w-8" />
              </div>
              <div>
                <CardTitle className="text-2xl">
                  Tier {currentTier.level}: {currentTier.name}
                </CardTitle>
                <CardDescription className="text-lg">
                  {currentTier.description}
                </CardDescription>
              </div>
            </div>
            <Badge className={`${currentTier.color} text-lg px-4 py-2`}>
              Current Tier
            </Badge>
          </div>
        </CardHeader>
        <CardContent>
          <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
            <div className="text-center">
              <div className="text-3xl font-bold text-green-600">£{userWinnings.toLocaleString()}</div>
              <div className="text-gray-600">Total Winnings</div>
            </div>
            <div className="text-center">
              <div className="text-3xl font-bold text-blue-600">{userStats.totalSyndicates || 0}</div>
              <div className="text-gray-600">Syndicates Joined</div>
            </div>
            <div className="text-center">
              <div className="text-3xl font-bold text-purple-600">{userStats.activeSyndicates || 0}</div>
              <div className="text-gray-600">Active Syndicates</div>
            </div>
          </div>

          {/* Progress to Next Tier */}
          {nextTier && (
            <div className="mt-6">
              <div className="flex justify-between items-center mb-2">
                <span className="text-sm font-medium">Progress to {nextTier.name}</span>
                <span className="text-sm text-gray-600">
                  £{remainingToNext.toLocaleString()} remaining
                </span>
              </div>
              <Progress value={progressToNext} className="h-3" />
              <div className="text-xs text-gray-500 mt-1">
                {progressToNext.toFixed(1)}% complete
              </div>
            </div>
          )}

          {/* Current Tier Benefits */}
          <div className="mt-6">
            <h4 className="font-semibold mb-3">Your Current Benefits:</h4>
            <div className="grid grid-cols-1 md:grid-cols-3 gap-2">
              {currentTier.benefits.map((benefit, index) => (
                <div key={index} className="flex items-center gap-2">
                  <CheckCircle className="h-4 w-4 text-green-600" />
                  <span className="text-sm">{benefit}</span>
                </div>
              ))}
            </div>
          </div>
        </CardContent>
      </Card>

      {/* All Tiers Overview */}
      <Card>
        <CardHeader>
          <CardTitle>Tier System Overview</CardTitle>
          <CardDescription>
            Unlock new benefits and exclusive syndicate access as you achieve winnings milestones
          </CardDescription>
        </CardHeader>
        <CardContent>
          <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
            {tiers.map((tier) => {
              const isUnlocked = userTier >= tier.level;
              const isCurrent = userTier === tier.level;
              const IconComponent = tier.icon;
              
              return (
                <Card 
                  key={tier.level} 
                  className={`relative ${
                    isCurrent 
                      ? 'ring-2 ring-blue-500 bg-blue-50' 
                      : isUnlocked 
                        ? 'bg-white' 
                        : 'bg-gray-50 opacity-75'
                  }`}
                >
                  <CardContent className="pt-6">
                    <div className="flex items-center justify-between mb-3">
                      <div className={`p-2 rounded-full ${tier.color}`}>
                        <IconComponent className="h-5 w-5" />
                      </div>
                      {isUnlocked ? (
                        <Unlock className="h-5 w-5 text-green-600" />
                      ) : (
                        <Lock className="h-5 w-5 text-gray-400" />
                      )}
                    </div>
                    
                    <h3 className="font-semibold mb-1">
                      Tier {tier.level}: {tier.name}
                    </h3>
                    
                    <Badge 
                      className={`mb-3 ${tier.color}`}
                      variant={isUnlocked ? "default" : "secondary"}
                    >
                      £{tier.threshold.toLocaleString()}+
                    </Badge>
                    
                    <div className="space-y-1">
                      {tier.benefits.slice(0, 2).map((benefit, index) => (
                        <div key={index} className="flex items-center gap-1">
                          <div className="w-1 h-1 bg-gray-400 rounded-full"></div>
                          <span className="text-xs text-gray-600">{benefit}</span>
                        </div>
                      ))}
                      {tier.benefits.length > 2 && (
                        <div className="text-xs text-gray-500">
                          +{tier.benefits.length - 2} more benefits
                        </div>
                      )}
                    </div>
                    
                    {isCurrent && (
                      <Badge className="absolute -top-2 -right-2 bg-blue-600">
                        Current
                      </Badge>
                    )}
                  </CardContent>
                </Card>
              );
            })}
          </div>
        </CardContent>
      </Card>
    </div>
  );
};

// Lottery Integration Component
export const LotteryIntegration = ({ lotteries = [], upcomingDraws = [], recentResults = [] }) => {
  const [selectedLottery, setSelectedLottery] = useState(null);

  return (
    <div className="space-y-6">
      {/* Lottery Overview */}
      <Card>
        <CardHeader>
          <CardTitle>Lottery Integration</CardTitle>
          <CardDescription>
            Real-time lottery information and syndicate opportunities across 9 international lotteries
          </CardDescription>
        </CardHeader>
        <CardContent>
          <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
            {lotteries.slice(0, 9).map((lottery) => (
              <Card 
                key={lottery.id} 
                className={`cursor-pointer transition-all hover:shadow-lg ${
                  selectedLottery?.id === lottery.id ? 'ring-2 ring-blue-500' : ''
                }`}
                onClick={() => setSelectedLottery(lottery)}
              >
                <CardContent className="pt-6">
                  <div className="flex items-center gap-3 mb-4">
                    <span className="text-3xl">{lottery.country_flag}</span>
                    <div>
                      <h3 className="font-semibold">{lottery.name}</h3>
                      <p className="text-sm text-gray-600">{lottery.country}</p>
                    </div>
                  </div>
                  
                  <Badge variant="outline" className="mb-3">
                    {lottery.format}
                  </Badge>
                  
                  <div className="space-y-2 text-sm">
                    <div className="flex justify-between">
                      <span>Next Draw:</span>
                      <span className="font-medium">
                        {lottery.next_draw_date ? 
                          new Date(lottery.next_draw_date).toLocaleDateString() : 
                          'TBA'
                        }
                      </span>
                    </div>
                    <div className="flex justify-between">
                      <span>Active Syndicates:</span>
                      <span className="font-medium text-blue-600">
                        {lottery.active_syndicates || 0}
                      </span>
                    </div>
                    <div className="flex justify-between">
                      <span>Jackpot:</span>
                      <span className="font-medium text-green-600">
                        £{(lottery.current_jackpot || 0).toLocaleString()}
                      </span>
                    </div>
                  </div>
                </CardContent>
              </Card>
            ))}
          </div>
        </CardContent>
      </Card>

      {/* Upcoming Draws */}
      <Card>
        <CardHeader>
          <CardTitle>Upcoming Draws</CardTitle>
          <CardDescription>
            Don't miss out on upcoming lottery draws across all supported lotteries
          </CardDescription>
        </CardHeader>
        <CardContent>
          <div className="space-y-4">
            {upcomingDraws.length > 0 ? (
              upcomingDraws.map((draw, index) => (
                <div key={index} className="flex items-center justify-between p-4 border rounded-lg">
                  <div className="flex items-center gap-4">
                    <span className="text-2xl">{draw.lottery_flag}</span>
                    <div>
                      <h4 className="font-semibold">{draw.lottery_name}</h4>
                      <p className="text-sm text-gray-600">
                        Draw #{draw.draw_number} • {draw.format}
                      </p>
                    </div>
                  </div>
                  
                  <div className="text-right">
                    <div className="font-semibold text-lg">
                      £{draw.jackpot.toLocaleString()}
                    </div>
                    <div className="text-sm text-gray-600">
                      {new Date(draw.draw_date).toLocaleDateString()} at {draw.draw_time}
                    </div>
                    <Badge className="mt-1">
                      {draw.available_syndicates} syndicates available
                    </Badge>
                  </div>
                </div>
              ))
            ) : (
              <div className="text-center py-8">
                <Calendar className="h-12 w-12 text-gray-400 mx-auto mb-4" />
                <h3 className="text-lg font-medium text-gray-900 mb-2">No upcoming draws</h3>
                <p className="text-gray-600">Check back later for upcoming lottery draws</p>
              </div>
            )}
          </div>
        </CardContent>
      </Card>

      {/* Recent Results */}
      <Card>
        <CardHeader>
          <CardTitle>Recent Results</CardTitle>
          <CardDescription>
            Latest lottery results and syndicate performance
          </CardDescription>
        </CardHeader>
        <CardContent>
          <Tabs defaultValue="results">
            <TabsList>
              <TabsTrigger value="results">Lottery Results</TabsTrigger>
              <TabsTrigger value="syndicate-wins">Syndicate Wins</TabsTrigger>
            </TabsList>
            
            <TabsContent value="results" className="space-y-4">
              {recentResults.length > 0 ? (
                recentResults.map((result, index) => (
                  <div key={index} className="p-4 border rounded-lg">
                    <div className="flex items-center justify-between mb-3">
                      <div className="flex items-center gap-3">
                        <span className="text-xl">{result.lottery_flag}</span>
                        <div>
                          <h4 className="font-semibold">{result.lottery_name}</h4>
                          <p className="text-sm text-gray-600">
                            Draw #{result.draw_number} • {new Date(result.draw_date).toLocaleDateString()}
                          </p>
                        </div>
                      </div>
                      <Badge className="bg-green-100 text-green-800">
                        £{result.jackpot_won.toLocaleString()} won
                      </Badge>
                    </div>
                    
                    <div className="flex items-center gap-4">
                      <div>
                        <span className="text-sm text-gray-600">Winning Numbers:</span>
                        <div className="flex gap-2 mt-1">
                          {result.winning_numbers.map((number, idx) => (
                            <div key={idx} className="w-8 h-8 bg-blue-600 text-white rounded-full flex items-center justify-center text-sm font-semibold">
                              {number}
                            </div>
                          ))}
                          {result.bonus_numbers && result.bonus_numbers.length > 0 && (
                            <>
                              <span className="text-gray-400 mx-2">+</span>
                              {result.bonus_numbers.map((number, idx) => (
                                <div key={idx} className="w-8 h-8 bg-orange-600 text-white rounded-full flex items-center justify-center text-sm font-semibold">
                                  {number}
                                </div>
                              ))}
                            </>
                          )}
                        </div>
                      </div>
                    </div>
                  </div>
                ))
              ) : (
                <div className="text-center py-8">
                  <Trophy className="h-12 w-12 text-gray-400 mx-auto mb-4" />
                  <h3 className="text-lg font-medium text-gray-900 mb-2">No recent results</h3>
                  <p className="text-gray-600">Recent lottery results will appear here</p>
                </div>
              )}
            </TabsContent>
            
            <TabsContent value="syndicate-wins" className="space-y-4">
              <div className="text-center py-8">
                <Award className="h-12 w-12 text-gray-400 mx-auto mb-4" />
                <h3 className="text-lg font-medium text-gray-900 mb-2">No syndicate wins yet</h3>
                <p className="text-gray-600">Syndicate winnings will be displayed here</p>
              </div>
            </TabsContent>
          </Tabs>
        </CardContent>
      </Card>
    </div>
  );
};

// Tier Unlocking Component
export const TierUnlocking = ({ onTierUnlock, availableUpgrades = [] }) => {
  const [selectedUpgrade, setSelectedUpgrade] = useState(null);

  const handleUnlock = async (tierLevel) => {
    try {
      await onTierUnlock(tierLevel);
    } catch (error) {
      console.error('Error unlocking tier:', error);
    }
  };

  return (
    <div className="space-y-6">
      <Card>
        <CardHeader>
          <CardTitle>Tier Unlocking</CardTitle>
          <CardDescription>
            Unlock new tier benefits based on your winnings achievements
          </CardDescription>
        </CardHeader>
        <CardContent>
          {availableUpgrades.length > 0 ? (
            <div className="space-y-4">
              {availableUpgrades.map((upgrade) => (
                <Card key={upgrade.tier_level} className="border-green-200 bg-green-50">
                  <CardContent className="pt-6">
                    <div className="flex items-center justify-between">
                      <div className="flex items-center gap-4">
                        <div className="p-3 bg-green-600 text-white rounded-full">
                          <upgrade.icon className="h-6 w-6" />
                        </div>
                        <div>
                          <h3 className="font-semibold text-lg">
                            Tier {upgrade.tier_level}: {upgrade.tier_name}
                          </h3>
                          <p className="text-gray-600">{upgrade.description}</p>
                          <div className="flex gap-2 mt-2">
                            {upgrade.new_benefits.map((benefit, index) => (
                              <Badge key={index} className="bg-green-100 text-green-800">
                                {benefit}
                              </Badge>
                            ))}
                          </div>
                        </div>
                      </div>
                      <Button 
                        onClick={() => handleUnlock(upgrade.tier_level)}
                        className="bg-green-600 hover:bg-green-700"
                      >
                        <Unlock className="h-4 w-4 mr-2" />
                        Unlock Now
                      </Button>
                    </div>
                  </CardContent>
                </Card>
              ))}
            </div>
          ) : (
            <div className="text-center py-8">
              <Lock className="h-12 w-12 text-gray-400 mx-auto mb-4" />
              <h3 className="text-lg font-medium text-gray-900 mb-2">No tier upgrades available</h3>
              <p className="text-gray-600">
                Keep playing and winning to unlock new tier benefits!
              </p>
            </div>
          )}
        </CardContent>
      </Card>
    </div>
  );
};

export default { TierSystem, LotteryIntegration, TierUnlocking };

