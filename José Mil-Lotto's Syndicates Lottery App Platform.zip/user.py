from flask_sqlalchemy import SQLAlchemy
from datetime import datetime
from werkzeug.security import generate_password_hash, check_password_hash
import enum

db = SQLAlchemy()

# Enums for various choices
class SyndicateType(enum.Enum):
    STANDARD = "Standard"
    SUPER = "Super"

class RiskLevel(enum.Enum):
    CAUTIOUS = "Cautious"
    AMBITIOUS = "Ambitious"
    AUDACIOUS = "Audacious"

class FinancialEffort(enum.Enum):
    MINIMUM = "Minimum"
    MEDIUM = "Medium"
    MAXIMUM = "Maximum"

class SyndicateStatus(enum.Enum):
    PENDING = "Pending"
    ACTIVE = "Active"
    COMPLETED = "Completed"
    CANCELLED = "Cancelled"

class PaymentStatus(enum.Enum):
    PENDING = "Pending"
    COMPLETED = "Completed"
    FAILED = "Failed"
    REFUNDED = "Refunded"

class PrivilegeLevel(enum.Enum):
    CAPTAIN = "Syndicate Captain"
    MODERATOR = "Syndicate Moderator"
    REGULATOR = "Syndicate Regulator"

# User Model
class User(db.Model):
    __tablename__ = 'users'
    
    id = db.Column(db.Integer, primary_key=True)
    username = db.Column(db.String(80), unique=True, nullable=False, index=True)
    email = db.Column(db.String(120), unique=True, nullable=False, index=True)
    password_hash = db.Column(db.String(255), nullable=False)
    first_name = db.Column(db.String(50), nullable=False)
    last_name = db.Column(db.String(50), nullable=False)
    registration_date = db.Column(db.DateTime, default=datetime.utcnow)
    last_login = db.Column(db.DateTime)
    total_winnings = db.Column(db.Numeric(10, 2), default=0.00)
    current_tier_id = db.Column(db.Integer, db.ForeignKey('tiers.id'), default=1)
    language_preference = db.Column(db.String(5), default='en')
    is_active = db.Column(db.Boolean, default=True)
    is_verified = db.Column(db.Boolean, default=False)
    avatar_url = db.Column(db.String(255))
    social_google_id = db.Column(db.String(100))
    social_facebook_id = db.Column(db.String(100))
    social_linkedin_id = db.Column(db.String(100))
    created_at = db.Column(db.DateTime, default=datetime.utcnow)
    updated_at = db.Column(db.DateTime, default=datetime.utcnow, onupdate=datetime.utcnow)
    
    # Relationships
    current_tier = db.relationship('Tier', backref='users')
    shares = db.relationship('Share', backref='user', lazy='dynamic')
    created_syndicates = db.relationship('Syndicate', backref='creator', lazy='dynamic')
    privileges = db.relationship('UserPrivilege', foreign_keys='UserPrivilege.user_id', backref='user', lazy='dynamic')
    transactions = db.relationship('Transaction', backref='user', lazy='dynamic')
    forum_posts = db.relationship('ForumPost', backref='author', lazy='dynamic')
    
    def set_password(self, password):
        self.password_hash = generate_password_hash(password)
    
    def check_password(self, password):
        return check_password_hash(self.password_hash, password)
    
    def get_tier_level(self):
        return self.current_tier.level if self.current_tier else 1
    
    def can_access_tier(self, required_tier):
        return self.get_tier_level() >= required_tier
    
    def __repr__(self):
        return f'<User {self.username}>'
    
    def to_dict(self):
        return {
            'id': self.id,
            'username': self.username,
            'email': self.email,
            'first_name': self.first_name,
            'last_name': self.last_name,
            'total_winnings': float(self.total_winnings),
            'current_tier': self.current_tier.to_dict() if self.current_tier else None,
            'language_preference': self.language_preference,
            'is_active': self.is_active,
            'is_verified': self.is_verified,
            'avatar_url': self.avatar_url,
            'registration_date': self.registration_date.isoformat() if self.registration_date else None,
            'last_login': self.last_login.isoformat() if self.last_login else None
        }

# Tier Model
class Tier(db.Model):
    __tablename__ = 'tiers'
    
    id = db.Column(db.Integer, primary_key=True)
    level = db.Column(db.Integer, unique=True, nullable=False)
    name = db.Column(db.String(50), nullable=False)
    required_winnings = db.Column(db.Numeric(10, 2), nullable=False)
    created_at = db.Column(db.DateTime, default=datetime.utcnow)
    
    def __repr__(self):
        return f'<Tier {self.level}: {self.name}>'
    
    def to_dict(self):
        return {
            'id': self.id,
            'level': self.level,
            'name': self.name,
            'required_winnings': float(self.required_winnings)
        }

# Lottery Model
class Lottery(db.Model):
    __tablename__ = 'lotteries'
    
    id = db.Column(db.Integer, primary_key=True)
    name = db.Column(db.String(100), nullable=False)
    country = db.Column(db.String(50), nullable=False)
    flag_emoji = db.Column(db.String(10), nullable=False)
    numbers_count = db.Column(db.Integer, nullable=False)
    numbers_range = db.Column(db.Integer, nullable=False)
    has_bonus_numbers = db.Column(db.Boolean, default=False)
    bonus_count = db.Column(db.Integer, default=0)
    bonus_range = db.Column(db.Integer, default=0)
    draw_days = db.Column(db.String(50))  # e.g., "Wednesday,Saturday"
    draw_time = db.Column(db.Time)
    is_active = db.Column(db.Boolean, default=True)
    created_at = db.Column(db.DateTime, default=datetime.utcnow)
    
    # Relationships
    syndicates = db.relationship('Syndicate', backref='lottery', lazy='dynamic')
    draw_schedules = db.relationship('DrawSchedule', backref='lottery', lazy='dynamic')
    
    def get_format(self):
        return f"{self.numbers_count}/{self.numbers_range}"
    
    def __repr__(self):
        return f'<Lottery {self.name}>'
    
    def to_dict(self):
        return {
            'id': self.id,
            'name': self.name,
            'country': self.country,
            'flag': self.flag_emoji,
            'format': self.get_format(),
            'numbers_count': self.numbers_count,
            'numbers_range': self.numbers_range,
            'has_bonus_numbers': self.has_bonus_numbers,
            'bonus_count': self.bonus_count,
            'bonus_range': self.bonus_range,
            'draw_days': self.draw_days,
            'draw_time': self.draw_time.strftime('%H:%M') if self.draw_time else None,
            'is_active': self.is_active
        }

# Syndicate Model
class Syndicate(db.Model):
    __tablename__ = 'syndicates'
    
    id = db.Column(db.Integer, primary_key=True)
    name = db.Column(db.String(200), nullable=False)
    creator_id = db.Column(db.Integer, db.ForeignKey('users.id'), nullable=False)
    lottery_id = db.Column(db.Integer, db.ForeignKey('lotteries.id'), nullable=False)
    syndicate_type = db.Column(db.Enum(SyndicateType), nullable=False)
    risk_level = db.Column(db.Enum(RiskLevel), nullable=False)
    financial_effort = db.Column(db.Enum(FinancialEffort), nullable=False)
    tier_level = db.Column(db.Integer, nullable=False, default=1)
    start_date = db.Column(db.Date, nullable=False)
    end_date = db.Column(db.Date, nullable=False)
    total_draws = db.Column(db.Integer, nullable=False)
    remaining_draws = db.Column(db.Integer, nullable=False)
    total_entries = db.Column(db.Integer, nullable=False)
    total_shares = db.Column(db.Integer, nullable=False)
    available_shares = db.Column(db.Integer, nullable=False)
    share_price = db.Column(db.Numeric(10, 2), nullable=False)
    status = db.Column(db.Enum(SyndicateStatus), default=SyndicateStatus.PENDING)
    description = db.Column(db.Text)
    created_at = db.Column(db.DateTime, default=datetime.utcnow)
    updated_at = db.Column(db.DateTime, default=datetime.utcnow, onupdate=datetime.utcnow)
    
    # Relationships
    shares = db.relationship('Share', backref='syndicate', lazy='dynamic')
    entries = db.relationship('Entry', backref='syndicate', lazy='dynamic')
    
    def is_full(self):
        return self.available_shares == 0
    
    def get_participation_percentage(self):
        return ((self.total_shares - self.available_shares) / self.total_shares) * 100
    
    def __repr__(self):
        return f'<Syndicate {self.name}>'
    
    def to_dict(self):
        return {
            'id': self.id,
            'name': self.name,
            'creator_id': self.creator_id,
            'lottery': self.lottery.to_dict() if self.lottery else None,
            'syndicate_type': self.syndicate_type.value,
            'risk_level': self.risk_level.value,
            'financial_effort': self.financial_effort.value,
            'tier_level': self.tier_level,
            'start_date': self.start_date.isoformat() if self.start_date else None,
            'end_date': self.end_date.isoformat() if self.end_date else None,
            'total_draws': self.total_draws,
            'remaining_draws': self.remaining_draws,
            'total_entries': self.total_entries,
            'total_shares': self.total_shares,
            'available_shares': self.available_shares,
            'share_price': float(self.share_price),
            'status': self.status.value,
            'description': self.description,
            'participation_percentage': self.get_participation_percentage(),
            'is_full': self.is_full(),
            'created_at': self.created_at.isoformat() if self.created_at else None
        }

# Share Model
class Share(db.Model):
    __tablename__ = 'shares'
    
    id = db.Column(db.Integer, primary_key=True)
    syndicate_id = db.Column(db.Integer, db.ForeignKey('syndicates.id'), nullable=False)
    user_id = db.Column(db.Integer, db.ForeignKey('users.id'), nullable=True)  # Null for Mil-Lotto's share
    percentage = db.Column(db.Numeric(5, 2), nullable=False)
    purchase_date = db.Column(db.DateTime, default=datetime.utcnow)
    payment_status = db.Column(db.Enum(PaymentStatus), default=PaymentStatus.PENDING)
    payment_reference = db.Column(db.String(100))
    is_mil_lotto_share = db.Column(db.Boolean, default=False)
    created_at = db.Column(db.DateTime, default=datetime.utcnow)
    updated_at = db.Column(db.DateTime, default=datetime.utcnow, onupdate=datetime.utcnow)
    
    def __repr__(self):
        return f'<Share {self.id}: {self.percentage}% of Syndicate {self.syndicate_id}>'
    
    def to_dict(self):
        return {
            'id': self.id,
            'syndicate_id': self.syndicate_id,
            'user_id': self.user_id,
            'percentage': float(self.percentage),
            'purchase_date': self.purchase_date.isoformat() if self.purchase_date else None,
            'payment_status': self.payment_status.value,
            'payment_reference': self.payment_reference,
            'is_mil_lotto_share': self.is_mil_lotto_share
        }

# Entry Model
class Entry(db.Model):
    __tablename__ = 'entries'
    
    id = db.Column(db.Integer, primary_key=True)
    syndicate_id = db.Column(db.Integer, db.ForeignKey('syndicates.id'), nullable=False)
    numbers_selected = db.Column(db.String(100), nullable=False)  # Comma-separated numbers
    bonus_numbers = db.Column(db.String(50))  # Comma-separated bonus numbers
    draw_number = db.Column(db.Integer, nullable=False)
    draw_date = db.Column(db.Date)
    result = db.Column(db.String(100))  # Winning numbers
    bonus_result = db.Column(db.String(50))  # Winning bonus numbers
    matches = db.Column(db.Integer, default=0)
    bonus_matches = db.Column(db.Integer, default=0)
    prize_tier = db.Column(db.String(50))
    winnings = db.Column(db.Numeric(10, 2), default=0.00)
    status = db.Column(db.String(20), default='Pending')
    created_at = db.Column(db.DateTime, default=datetime.utcnow)
    updated_at = db.Column(db.DateTime, default=datetime.utcnow, onupdate=datetime.utcnow)
    
    def get_numbers_list(self):
        return [int(n) for n in self.numbers_selected.split(',') if n.strip()]
    
    def get_bonus_numbers_list(self):
        if self.bonus_numbers:
            return [int(n) for n in self.bonus_numbers.split(',') if n.strip()]
        return []
    
    def __repr__(self):
        return f'<Entry {self.id}: {self.numbers_selected}>'
    
    def to_dict(self):
        return {
            'id': self.id,
            'syndicate_id': self.syndicate_id,
            'numbers_selected': self.get_numbers_list(),
            'bonus_numbers': self.get_bonus_numbers_list(),
            'draw_number': self.draw_number,
            'draw_date': self.draw_date.isoformat() if self.draw_date else None,
            'result': self.result,
            'bonus_result': self.bonus_result,
            'matches': self.matches,
            'bonus_matches': self.bonus_matches,
            'prize_tier': self.prize_tier,
            'winnings': float(self.winnings),
            'status': self.status
        }

# Draw Schedule Model
class DrawSchedule(db.Model):
    __tablename__ = 'draw_schedules'
    
    id = db.Column(db.Integer, primary_key=True)
    lottery_id = db.Column(db.Integer, db.ForeignKey('lotteries.id'), nullable=False)
    draw_date = db.Column(db.Date, nullable=False)
    draw_time = db.Column(db.Time, nullable=False)
    estimated_jackpot = db.Column(db.Numeric(12, 2))
    estimated_jackpot_gbp = db.Column(db.Numeric(12, 2))
    is_completed = db.Column(db.Boolean, default=False)
    created_at = db.Column(db.DateTime, default=datetime.utcnow)
    
    # Relationships
    results = db.relationship('DrawResult', backref='schedule', uselist=False)
    
    def __repr__(self):
        return f'<DrawSchedule {self.lottery.name} on {self.draw_date}>'
    
    def to_dict(self):
        return {
            'id': self.id,
            'lottery_id': self.lottery_id,
            'draw_date': self.draw_date.isoformat() if self.draw_date else None,
            'draw_time': self.draw_time.strftime('%H:%M') if self.draw_time else None,
            'estimated_jackpot': float(self.estimated_jackpot) if self.estimated_jackpot else None,
            'estimated_jackpot_gbp': float(self.estimated_jackpot_gbp) if self.estimated_jackpot_gbp else None,
            'is_completed': self.is_completed
        }

# Draw Result Model
class DrawResult(db.Model):
    __tablename__ = 'draw_results'
    
    id = db.Column(db.Integer, primary_key=True)
    lottery_id = db.Column(db.Integer, db.ForeignKey('lotteries.id'), nullable=False)
    schedule_id = db.Column(db.Integer, db.ForeignKey('draw_schedules.id'), nullable=False)
    draw_date = db.Column(db.Date, nullable=False)
    numbers_drawn = db.Column(db.String(100), nullable=False)
    bonus_numbers = db.Column(db.String(50))
    jackpot_amount = db.Column(db.Numeric(12, 2))
    jackpot_gbp = db.Column(db.Numeric(12, 2))
    has_jackpot_winner = db.Column(db.Boolean, default=False)
    created_at = db.Column(db.DateTime, default=datetime.utcnow)
    updated_at = db.Column(db.DateTime, default=datetime.utcnow, onupdate=datetime.utcnow)
    
    def get_numbers_list(self):
        return [int(n) for n in self.numbers_drawn.split(',') if n.strip()]
    
    def get_bonus_numbers_list(self):
        if self.bonus_numbers:
            return [int(n) for n in self.bonus_numbers.split(',') if n.strip()]
        return []
    
    def __repr__(self):
        return f'<DrawResult {self.lottery.name} on {self.draw_date}>'
    
    def to_dict(self):
        return {
            'id': self.id,
            'lottery_id': self.lottery_id,
            'schedule_id': self.schedule_id,
            'draw_date': self.draw_date.isoformat() if self.draw_date else None,
            'numbers_drawn': self.get_numbers_list(),
            'bonus_numbers': self.get_bonus_numbers_list(),
            'jackpot_amount': float(self.jackpot_amount) if self.jackpot_amount else None,
            'jackpot_gbp': float(self.jackpot_gbp) if self.jackpot_gbp else None,
            'has_jackpot_winner': self.has_jackpot_winner
        }

# Transaction Model
class Transaction(db.Model):
    __tablename__ = 'transactions'
    
    id = db.Column(db.Integer, primary_key=True)
    user_id = db.Column(db.Integer, db.ForeignKey('users.id'), nullable=False)
    syndicate_id = db.Column(db.Integer, db.ForeignKey('syndicates.id'), nullable=True)
    transaction_type = db.Column(db.String(50), nullable=False)  # 'purchase', 'winnings', 'refund'
    amount = db.Column(db.Numeric(10, 2), nullable=False)
    description = db.Column(db.String(255))
    reference = db.Column(db.String(100))
    status = db.Column(db.Enum(PaymentStatus), default=PaymentStatus.PENDING)
    created_at = db.Column(db.DateTime, default=datetime.utcnow)
    updated_at = db.Column(db.DateTime, default=datetime.utcnow, onupdate=datetime.utcnow)
    
    def __repr__(self):
        return f'<Transaction {self.id}: {self.transaction_type} £{self.amount}>'
    
    def to_dict(self):
        return {
            'id': self.id,
            'user_id': self.user_id,
            'syndicate_id': self.syndicate_id,
            'transaction_type': self.transaction_type,
            'amount': float(self.amount),
            'description': self.description,
            'reference': self.reference,
            'status': self.status.value,
            'created_at': self.created_at.isoformat() if self.created_at else None
        }

# User Privilege Model
class UserPrivilege(db.Model):
    __tablename__ = 'user_privileges'
    
    id = db.Column(db.Integer, primary_key=True)
    user_id = db.Column(db.Integer, db.ForeignKey('users.id'), nullable=False)
    privilege_level = db.Column(db.Enum(PrivilegeLevel), nullable=False)
    granted_by = db.Column(db.Integer, db.ForeignKey('users.id'))
    granted_at = db.Column(db.DateTime, default=datetime.utcnow)
    is_active = db.Column(db.Boolean, default=True)
    
    # Relationships
    granter = db.relationship('User', foreign_keys=[granted_by])
    
    def __repr__(self):
        return f'<UserPrivilege {self.user.username}: {self.privilege_level.value}>'
    
    def to_dict(self):
        return {
            'id': self.id,
            'user_id': self.user_id,
            'privilege_level': self.privilege_level.value,
            'granted_by': self.granted_by,
            'granted_at': self.granted_at.isoformat() if self.granted_at else None,
            'is_active': self.is_active
        }

# Forum Category Model
class ForumCategory(db.Model):
    __tablename__ = 'forum_categories'
    
    id = db.Column(db.Integer, primary_key=True)
    name = db.Column(db.String(100), nullable=False)
    description = db.Column(db.Text)
    display_order = db.Column(db.Integer, default=0)
    is_active = db.Column(db.Boolean, default=True)
    created_at = db.Column(db.DateTime, default=datetime.utcnow)
    
    # Relationships
    topics = db.relationship('ForumTopic', backref='category', lazy='dynamic')
    
    def get_topic_count(self):
        return self.topics.filter_by(is_active=True).count()
    
    def get_post_count(self):
        return db.session.query(ForumPost).join(ForumTopic).filter(
            ForumTopic.category_id == self.id,
            ForumTopic.is_active == True,
            ForumPost.is_active == True
        ).count()
    
    def __repr__(self):
        return f'<ForumCategory {self.name}>'
    
    def to_dict(self):
        return {
            'id': self.id,
            'name': self.name,
            'description': self.description,
            'topic_count': self.get_topic_count(),
            'post_count': self.get_post_count(),
            'display_order': self.display_order,
            'is_active': self.is_active
        }

# Forum Topic Model
class ForumTopic(db.Model):
    __tablename__ = 'forum_topics'
    
    id = db.Column(db.Integer, primary_key=True)
    category_id = db.Column(db.Integer, db.ForeignKey('forum_categories.id'), nullable=False)
    title = db.Column(db.String(200), nullable=False)
    author_id = db.Column(db.Integer, db.ForeignKey('users.id'), nullable=False)
    is_pinned = db.Column(db.Boolean, default=False)
    is_locked = db.Column(db.Boolean, default=False)
    is_active = db.Column(db.Boolean, default=True)
    created_at = db.Column(db.DateTime, default=datetime.utcnow)
    updated_at = db.Column(db.DateTime, default=datetime.utcnow, onupdate=datetime.utcnow)
    
    # Relationships
    author = db.relationship('User', backref='forum_topics')
    posts = db.relationship('ForumPost', backref='topic', lazy='dynamic')
    
    def get_post_count(self):
        return self.posts.filter_by(is_active=True).count()
    
    def get_last_post(self):
        return self.posts.filter_by(is_active=True).order_by(ForumPost.created_at.desc()).first()
    
    def __repr__(self):
        return f'<ForumTopic {self.title}>'
    
    def to_dict(self):
        last_post = self.get_last_post()
        return {
            'id': self.id,
            'category_id': self.category_id,
            'title': self.title,
            'author': self.author.username,
            'post_count': self.get_post_count(),
            'is_pinned': self.is_pinned,
            'is_locked': self.is_locked,
            'is_active': self.is_active,
            'created_at': self.created_at.isoformat() if self.created_at else None,
            'last_post_at': last_post.created_at.isoformat() if last_post else None,
            'last_post_author': last_post.author.username if last_post else None
        }

# Forum Post Model
class ForumPost(db.Model):
    __tablename__ = 'forum_posts'
    
    id = db.Column(db.Integer, primary_key=True)
    topic_id = db.Column(db.Integer, db.ForeignKey('forum_topics.id'), nullable=False)
    author_id = db.Column(db.Integer, db.ForeignKey('users.id'), nullable=False)
    content = db.Column(db.Text, nullable=False)
    is_active = db.Column(db.Boolean, default=True)
    created_at = db.Column(db.DateTime, default=datetime.utcnow)
    updated_at = db.Column(db.DateTime, default=datetime.utcnow, onupdate=datetime.utcnow)
    
    def __repr__(self):
        return f'<ForumPost {self.id} in Topic {self.topic_id}>'
    
    def to_dict(self):
        return {
            'id': self.id,
            'topic_id': self.topic_id,
            'author': self.author.username,
            'content': self.content,
            'is_active': self.is_active,
            'created_at': self.created_at.isoformat() if self.created_at else None,
            'updated_at': self.updated_at.isoformat() if self.updated_at else None
        }

