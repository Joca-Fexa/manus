import React, { useState, useEffect } from 'react';
import { Button } from '@/components/ui/button';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { Textarea } from '@/components/ui/textarea';
import { Badge } from '@/components/ui/badge';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import { AlertCircle, Users, Target, DollarSign, Calendar, Trophy, Info } from 'lucide-react';

// Syndicate Creation Form Component
export const SyndicateCreationForm = ({ onSubmit, lotteries = [] }) => {
  const [formData, setFormData] = useState({
    name: '',
    description: '',
    lottery_id: '',
    syndicate_type: 'standard',
    risk_tolerance: 'cautious',
    financial_effort: 'minimum',
    max_participants: 10,
    entry_fee: 5.00,
    duration_draws: 8,
    max_entries: 333,
    is_public: true
  });
  
  const [errors, setErrors] = useState({});
  const [loading, setLoading] = useState(false);

  const syndicateTypes = {
    standard: {
      name: 'Standard Syndicate',
      description: 'Perfect for regular players',
      shares: 10,
      sharePercentage: 10,
      defaultDraws: 8,
      maxEntries: 333,
      icon: Users
    },
    super: {
      name: 'Super Syndicate',
      description: 'For serious lottery enthusiasts',
      shares: 100,
      sharePercentage: 1,
      defaultDraws: 4,
      maxEntries: 999,
      icon: Trophy
    }
  };

  const riskLevels = {
    cautious: {
      name: 'Cautious',
      description: 'Conservative approach with steady participation',
      color: 'bg-green-100 text-green-800',
      multiplier: 1.0
    },
    ambitious: {
      name: 'Ambitious',
      description: 'Balanced risk with good potential returns',
      color: 'bg-yellow-100 text-yellow-800',
      multiplier: 1.5
    },
    audacious: {
      name: 'Audacious',
      description: 'High risk, high reward strategy',
      color: 'bg-red-100 text-red-800',
      multiplier: 2.0
    }
  };

  const financialEfforts = {
    minimum: { name: 'Minimum', range: '£5-15', baseAmount: 5 },
    medium: { name: 'Medium', range: '£15-35', baseAmount: 15 },
    maximum: { name: 'Maximum', range: '£35-75', baseAmount: 35 }
  };

  useEffect(() => {
    const type = syndicateTypes[formData.syndicate_type];
    const effort = financialEfforts[formData.financial_effort];
    const risk = riskLevels[formData.risk_tolerance];
    
    setFormData(prev => ({
      ...prev,
      max_participants: type.shares,
      duration_draws: type.defaultDraws,
      max_entries: type.maxEntries,
      entry_fee: Math.round(effort.baseAmount * risk.multiplier * 100) / 100
    }));
  }, [formData.syndicate_type, formData.financial_effort, formData.risk_tolerance]);

  const handleInputChange = (field, value) => {
    setFormData(prev => ({ ...prev, [field]: value }));
    if (errors[field]) {
      setErrors(prev => ({ ...prev, [field]: '' }));
    }
  };

  const validateForm = () => {
    const newErrors = {};
    
    if (!formData.name.trim()) newErrors.name = 'Syndicate name is required';
    if (!formData.description.trim()) newErrors.description = 'Description is required';
    if (!formData.lottery_id) newErrors.lottery_id = 'Please select a lottery';
    if (formData.entry_fee < 1) newErrors.entry_fee = 'Entry fee must be at least £1';
    
    setErrors(newErrors);
    return Object.keys(newErrors).length === 0;
  };

  const handleSubmit = async (e) => {
    e.preventDefault();
    if (validateForm()) {
      setLoading(true);
      try {
        await onSubmit(formData);
      } catch (error) {
        console.error('Error creating syndicate:', error);
      } finally {
        setLoading(false);
      }
    }
  };

  const selectedLottery = lotteries.find(l => l.id === parseInt(formData.lottery_id));
  const currentType = syndicateTypes[formData.syndicate_type];
  const currentRisk = riskLevels[formData.risk_tolerance];
  const currentEffort = financialEfforts[formData.financial_effort];

  return (
    <div className="max-w-4xl mx-auto p-6">
      <Card>
        <CardHeader>
          <CardTitle className="flex items-center gap-2">
            <Users className="h-6 w-6" />
            Create New Syndicate
          </CardTitle>
          <CardDescription>
            Set up your lottery syndicate and invite players to join
          </CardDescription>
        </CardHeader>
        <CardContent>
          <form onSubmit={handleSubmit} className="space-y-6">
            {/* Basic Information */}
            <div className="space-y-4">
              <h3 className="text-lg font-semibold">Basic Information</h3>
              
              <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                <div className="space-y-2">
                  <Label htmlFor="name">Syndicate Name</Label>
                  <Input
                    id="name"
                    value={formData.name}
                    onChange={(e) => handleInputChange('name', e.target.value)}
                    placeholder="Enter syndicate name"
                    className={errors.name ? 'border-red-500' : ''}
                  />
                  {errors.name && <p className="text-sm text-red-500">{errors.name}</p>}
                </div>
                
                <div className="space-y-2">
                  <Label htmlFor="lottery">Lottery</Label>
                  <Select value={formData.lottery_id} onValueChange={(value) => handleInputChange('lottery_id', value)}>
                    <SelectTrigger className={errors.lottery_id ? 'border-red-500' : ''}>
                      <SelectValue placeholder="Select a lottery" />
                    </SelectTrigger>
                    <SelectContent>
                      {lotteries.map((lottery) => (
                        <SelectItem key={lottery.id} value={lottery.id.toString()}>
                          <div className="flex items-center gap-2">
                            <span>{lottery.country_flag}</span>
                            <span>{lottery.name}</span>
                            <span className="text-sm text-gray-500">({lottery.format})</span>
                          </div>
                        </SelectItem>
                      ))}
                    </SelectContent>
                  </Select>
                  {errors.lottery_id && <p className="text-sm text-red-500">{errors.lottery_id}</p>}
                </div>
              </div>
              
              <div className="space-y-2">
                <Label htmlFor="description">Description</Label>
                <Textarea
                  id="description"
                  value={formData.description}
                  onChange={(e) => handleInputChange('description', e.target.value)}
                  placeholder="Describe your syndicate strategy and goals"
                  rows={3}
                  className={errors.description ? 'border-red-500' : ''}
                />
                {errors.description && <p className="text-sm text-red-500">{errors.description}</p>}
              </div>
            </div>

            {/* Syndicate Configuration */}
            <div className="space-y-4">
              <h3 className="text-lg font-semibold">Syndicate Configuration</h3>
              
              <Tabs value={formData.syndicate_type} onValueChange={(value) => handleInputChange('syndicate_type', value)}>
                <TabsList className="grid w-full grid-cols-2">
                  <TabsTrigger value="standard">Standard Syndicate</TabsTrigger>
                  <TabsTrigger value="super">Super Syndicate</TabsTrigger>
                </TabsList>
                
                <TabsContent value="standard" className="space-y-4">
                  <Card>
                    <CardContent className="pt-6">
                      <div className="flex items-center gap-3 mb-4">
                        <Users className="h-8 w-8 text-blue-600" />
                        <div>
                          <h4 className="font-semibold">Standard Syndicate</h4>
                          <p className="text-sm text-gray-600">Perfect for regular players</p>
                        </div>
                      </div>
                      <div className="grid grid-cols-2 md:grid-cols-4 gap-4 text-sm">
                        <div>
                          <span className="font-medium">Shares:</span>
                          <p>10 shares of 10% each</p>
                        </div>
                        <div>
                          <span className="font-medium">Duration:</span>
                          <p>8 consecutive draws</p>
                        </div>
                        <div>
                          <span className="font-medium">Max Entries:</span>
                          <p>Up to 333 number sets</p>
                        </div>
                        <div>
                          <span className="font-medium">Investment:</span>
                          <p>Lower, steady participation</p>
                        </div>
                      </div>
                    </CardContent>
                  </Card>
                </TabsContent>
                
                <TabsContent value="super" className="space-y-4">
                  <Card>
                    <CardContent className="pt-6">
                      <div className="flex items-center gap-3 mb-4">
                        <Trophy className="h-8 w-8 text-purple-600" />
                        <div>
                          <h4 className="font-semibold">Super Syndicate</h4>
                          <p className="text-sm text-gray-600">For serious lottery enthusiasts</p>
                        </div>
                      </div>
                      <div className="grid grid-cols-2 md:grid-cols-4 gap-4 text-sm">
                        <div>
                          <span className="font-medium">Shares:</span>
                          <p>100 shares of 1% each</p>
                        </div>
                        <div>
                          <span className="font-medium">Duration:</span>
                          <p>4 consecutive draws</p>
                        </div>
                        <div>
                          <span className="font-medium">Max Entries:</span>
                          <p>Up to 999 number sets</p>
                        </div>
                        <div>
                          <span className="font-medium">Investment:</span>
                          <p>Higher, maximum coverage</p>
                        </div>
                      </div>
                    </CardContent>
                  </Card>
                </TabsContent>
              </Tabs>
            </div>

            {/* Risk and Financial Configuration */}
            <div className="space-y-4">
              <h3 className="text-lg font-semibold">Risk & Financial Settings</h3>
              
              <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                <div className="space-y-3">
                  <Label>Risk Tolerance</Label>
                  <div className="space-y-2">
                    {Object.entries(riskLevels).map(([key, risk]) => (
                      <div
                        key={key}
                        className={`p-3 border rounded-lg cursor-pointer transition-colors ${
                          formData.risk_tolerance === key 
                            ? 'border-blue-500 bg-blue-50' 
                            : 'border-gray-200 hover:border-gray-300'
                        }`}
                        onClick={() => handleInputChange('risk_tolerance', key)}
                      >
                        <div className="flex items-center justify-between">
                          <div>
                            <div className="flex items-center gap-2">
                              <span className="font-medium">{risk.name}</span>
                              <Badge className={risk.color}>{risk.name}</Badge>
                            </div>
                            <p className="text-sm text-gray-600">{risk.description}</p>
                          </div>
                          <Target className="h-5 w-5 text-gray-400" />
                        </div>
                      </div>
                    ))}
                  </div>
                </div>
                
                <div className="space-y-3">
                  <Label>Financial Effort</Label>
                  <div className="space-y-2">
                    {Object.entries(financialEfforts).map(([key, effort]) => (
                      <div
                        key={key}
                        className={`p-3 border rounded-lg cursor-pointer transition-colors ${
                          formData.financial_effort === key 
                            ? 'border-green-500 bg-green-50' 
                            : 'border-gray-200 hover:border-gray-300'
                        }`}
                        onClick={() => handleInputChange('financial_effort', key)}
                      >
                        <div className="flex items-center justify-between">
                          <div>
                            <div className="flex items-center gap-2">
                              <span className="font-medium">{effort.name}</span>
                              <Badge variant="outline">{effort.range}</Badge>
                            </div>
                            <p className="text-sm text-gray-600">Entry fee range</p>
                          </div>
                          <DollarSign className="h-5 w-5 text-gray-400" />
                        </div>
                      </div>
                    ))}
                  </div>
                </div>
              </div>
            </div>

            {/* Summary */}
            <div className="space-y-4">
              <h3 className="text-lg font-semibold">Syndicate Summary</h3>
              <Card className="bg-gray-50">
                <CardContent className="pt-6">
                  <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
                    <div className="text-center">
                      <div className="text-2xl font-bold text-blue-600">£{formData.entry_fee}</div>
                      <div className="text-sm text-gray-600">Entry Fee</div>
                    </div>
                    <div className="text-center">
                      <div className="text-2xl font-bold text-green-600">{formData.max_participants}</div>
                      <div className="text-sm text-gray-600">Max Participants</div>
                    </div>
                    <div className="text-center">
                      <div className="text-2xl font-bold text-purple-600">{formData.duration_draws}</div>
                      <div className="text-sm text-gray-600">Draws</div>
                    </div>
                    <div className="text-center">
                      <div className="text-2xl font-bold text-orange-600">{formData.max_entries}</div>
                      <div className="text-sm text-gray-600">Max Entries</div>
                    </div>
                  </div>
                  
                  {selectedLottery && (
                    <div className="mt-4 p-3 bg-white rounded-lg">
                      <div className="flex items-center gap-2">
                        <span className="text-2xl">{selectedLottery.country_flag}</span>
                        <div>
                          <div className="font-medium">{selectedLottery.name}</div>
                          <div className="text-sm text-gray-600">{selectedLottery.format}</div>
                        </div>
                      </div>
                    </div>
                  )}
                </CardContent>
              </Card>
            </div>

            {/* Submit Button */}
            <div className="flex justify-end space-x-4">
              <Button type="button" variant="outline">
                Save as Draft
              </Button>
              <Button type="submit" disabled={loading}>
                {loading ? 'Creating Syndicate...' : 'Create Syndicate'}
              </Button>
            </div>
          </form>
        </CardContent>
      </Card>
    </div>
  );
};

// Syndicate Management Dashboard Component
export const SyndicateManagement = ({ syndicates = [], onJoinSyndicate, onLeaveSyndicate }) => {
  const [filter, setFilter] = useState('all');
  const [searchTerm, setSearchTerm] = useState('');

  const filteredSyndicates = syndicates.filter(syndicate => {
    const matchesSearch = syndicate.name.toLowerCase().includes(searchTerm.toLowerCase()) ||
                         syndicate.description.toLowerCase().includes(searchTerm.toLowerCase());
    
    if (filter === 'all') return matchesSearch;
    if (filter === 'joined') return matchesSearch && syndicate.user_joined;
    if (filter === 'available') return matchesSearch && !syndicate.user_joined && syndicate.available_shares > 0;
    if (filter === 'full') return matchesSearch && syndicate.available_shares === 0;
    
    return matchesSearch;
  });

  return (
    <div className="space-y-6">
      {/* Header */}
      <div className="flex flex-col md:flex-row md:items-center md:justify-between gap-4">
        <div>
          <h2 className="text-2xl font-bold">Syndicate Management</h2>
          <p className="text-gray-600">Browse and manage your lottery syndicates</p>
        </div>
        <Button>
          <Users className="h-4 w-4 mr-2" />
          Create New Syndicate
        </Button>
      </div>

      {/* Filters */}
      <div className="flex flex-col md:flex-row gap-4">
        <div className="flex-1">
          <Input
            placeholder="Search syndicates..."
            value={searchTerm}
            onChange={(e) => setSearchTerm(e.target.value)}
          />
        </div>
        <Select value={filter} onValueChange={setFilter}>
          <SelectTrigger className="w-full md:w-48">
            <SelectValue />
          </SelectTrigger>
          <SelectContent>
            <SelectItem value="all">All Syndicates</SelectItem>
            <SelectItem value="joined">My Syndicates</SelectItem>
            <SelectItem value="available">Available to Join</SelectItem>
            <SelectItem value="full">Full Syndicates</SelectItem>
          </SelectContent>
        </Select>
      </div>

      {/* Syndicates Grid */}
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
        {filteredSyndicates.map((syndicate) => (
          <SyndicateCard
            key={syndicate.id}
            syndicate={syndicate}
            onJoin={() => onJoinSyndicate(syndicate.id)}
            onLeave={() => onLeaveSyndicate(syndicate.id)}
          />
        ))}
      </div>

      {filteredSyndicates.length === 0 && (
        <div className="text-center py-12">
          <Users className="h-12 w-12 text-gray-400 mx-auto mb-4" />
          <h3 className="text-lg font-medium text-gray-900 mb-2">No syndicates found</h3>
          <p className="text-gray-600">Try adjusting your search or filter criteria</p>
        </div>
      )}
    </div>
  );
};

// Individual Syndicate Card Component
export const SyndicateCard = ({ syndicate, onJoin, onLeave }) => {
  const getStatusColor = (status) => {
    switch (status) {
      case 'active': return 'bg-green-100 text-green-800';
      case 'full': return 'bg-blue-100 text-blue-800';
      case 'completed': return 'bg-gray-100 text-gray-800';
      default: return 'bg-yellow-100 text-yellow-800';
    }
  };

  const getRiskColor = (risk) => {
    switch (risk) {
      case 'cautious': return 'bg-green-100 text-green-800';
      case 'ambitious': return 'bg-yellow-100 text-yellow-800';
      case 'audacious': return 'bg-red-100 text-red-800';
      default: return 'bg-gray-100 text-gray-800';
    }
  };

  return (
    <Card className="hover:shadow-lg transition-shadow">
      <CardHeader>
        <div className="flex items-start justify-between">
          <div className="flex-1">
            <CardTitle className="text-lg">{syndicate.name}</CardTitle>
            <CardDescription className="mt-1">{syndicate.description}</CardDescription>
          </div>
          <Badge className={getStatusColor(syndicate.status)}>
            {syndicate.status}
          </Badge>
        </div>
      </CardHeader>
      <CardContent className="space-y-4">
        {/* Lottery Info */}
        <div className="flex items-center gap-2">
          <span className="text-xl">{syndicate.lottery?.country_flag}</span>
          <div>
            <div className="font-medium">{syndicate.lottery?.name}</div>
            <div className="text-sm text-gray-600">{syndicate.lottery?.format}</div>
          </div>
        </div>

        {/* Syndicate Details */}
        <div className="grid grid-cols-2 gap-4 text-sm">
          <div>
            <span className="font-medium">Type:</span>
            <p className="capitalize">{syndicate.syndicate_type}</p>
          </div>
          <div>
            <span className="font-medium">Entry Fee:</span>
            <p>£{syndicate.entry_fee}</p>
          </div>
          <div>
            <span className="font-medium">Participants:</span>
            <p>{syndicate.current_participants}/{syndicate.max_participants}</p>
          </div>
          <div>
            <span className="font-medium">Draws Left:</span>
            <p>{syndicate.remaining_draws}</p>
          </div>
        </div>

        {/* Risk and Effort Badges */}
        <div className="flex gap-2">
          <Badge className={getRiskColor(syndicate.risk_tolerance)}>
            {syndicate.risk_tolerance}
          </Badge>
          <Badge variant="outline">
            {syndicate.financial_effort}
          </Badge>
        </div>

        {/* Progress Bar */}
        <div className="space-y-2">
          <div className="flex justify-between text-sm">
            <span>Shares Filled</span>
            <span>{syndicate.current_participants}/{syndicate.max_participants}</span>
          </div>
          <div className="w-full bg-gray-200 rounded-full h-2">
            <div
              className="bg-blue-600 h-2 rounded-full"
              style={{
                width: `${(syndicate.current_participants / syndicate.max_participants) * 100}%`
              }}
            />
          </div>
        </div>

        {/* Action Button */}
        <div className="pt-2">
          {syndicate.user_joined ? (
            <Button variant="outline" onClick={onLeave} className="w-full">
              Leave Syndicate
            </Button>
          ) : syndicate.available_shares > 0 ? (
            <Button onClick={onJoin} className="w-full">
              Join Syndicate (£{syndicate.entry_fee})
            </Button>
          ) : (
            <Button disabled className="w-full">
              Syndicate Full
            </Button>
          )}
        </div>
      </CardContent>
    </Card>
  );
};

export default { SyndicateCreationForm, SyndicateManagement, SyndicateCard };

