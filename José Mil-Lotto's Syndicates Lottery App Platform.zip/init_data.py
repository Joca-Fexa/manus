from src.models.user import db
from datetime import datetime, time
from decimal import Decimal

def init_database_data():
    """Initialize the database with default data"""
    
    # Create tiers
    tiers_data = [
        {'level': 1, 'name': 'Starter', 'required_winnings': Decimal('0.00')},
        {'level': 2, 'name': 'Explorer', 'required_winnings': Decimal('500.00')},
        {'level': 3, 'name': 'Adventurer', 'required_winnings': Decimal('1000.00')},
        {'level': 4, 'name': 'Specialist', 'required_winnings': Decimal('2500.00')},
        {'level': 5, 'name': 'Expert', 'required_winnings': Decimal('5000.00')},
        {'level': 6, 'name': 'Master', 'required_winnings': Decimal('10000.00')},
        {'level': 7, 'name': 'Elite', 'required_winnings': Decimal('25000.00')},
        {'level': 8, 'name': 'Champion', 'required_winnings': Decimal('50000.00')},
        {'level': 9, 'name': 'Legend', 'required_winnings': Decimal('100000.00')}
    ]
    
    from src.models.user import Tier
    for tier_data in tiers_data:
        existing_tier = Tier.query.filter_by(level=tier_data['level']).first()
        if not existing_tier:
            tier = Tier(**tier_data)
            db.session.add(tier)
    
    # Create lotteries
    lotteries_data = [
        {
            'name': 'Norway Lotto',
            'country': 'Norway',
            'flag_emoji': '🇳🇴',
            'numbers_count': 7,
            'numbers_range': 34,
            'has_bonus_numbers': False,
            'draw_days': 'Wednesday,Saturday',
            'draw_time': time(20, 0)
        },
        {
            'name': 'Sweden Lotto',
            'country': 'Sweden',
            'flag_emoji': '🇸🇪',
            'numbers_count': 7,
            'numbers_range': 35,
            'has_bonus_numbers': False,
            'draw_days': 'Wednesday,Saturday',
            'draw_time': time(20, 0)
        },
        {
            'name': 'Denmark Lotto',
            'country': 'Denmark',
            'flag_emoji': '🇩🇰',
            'numbers_count': 7,
            'numbers_range': 36,
            'has_bonus_numbers': False,
            'draw_days': 'Wednesday,Saturday',
            'draw_time': time(20, 0)
        },
        {
            'name': 'Swiss Lotto',
            'country': 'Switzerland',
            'flag_emoji': '🇨🇭',
            'numbers_count': 6,
            'numbers_range': 42,
            'has_bonus_numbers': True,
            'bonus_count': 1,
            'bonus_range': 6,
            'draw_days': 'Wednesday,Saturday',
            'draw_time': time(20, 0)
        },
        {
            'name': 'Japan Lotto',
            'country': 'Japan',
            'flag_emoji': '🇯🇵',
            'numbers_count': 6,
            'numbers_range': 43,
            'has_bonus_numbers': False,
            'draw_days': 'Monday,Thursday',
            'draw_time': time(19, 0)
        },
        {
            'name': 'Irish Lottery',
            'country': 'Ireland',
            'flag_emoji': '🇮🇪',
            'numbers_count': 6,
            'numbers_range': 47,
            'has_bonus_numbers': True,
            'bonus_count': 1,
            'bonus_range': 47,
            'draw_days': 'Wednesday,Saturday',
            'draw_time': time(20, 0)
        },
        {
            'name': 'Spain Loteria',
            'country': 'Spain',
            'flag_emoji': '🇪🇸',
            'numbers_count': 6,
            'numbers_range': 49,
            'has_bonus_numbers': True,
            'bonus_count': 1,
            'bonus_range': 10,
            'draw_days': 'Thursday,Saturday',
            'draw_time': time(21, 30)
        },
        {
            'name': 'New York Lotto',
            'country': 'USA',
            'flag_emoji': '🇺🇸',
            'numbers_count': 6,
            'numbers_range': 59,
            'has_bonus_numbers': False,
            'draw_days': 'Wednesday,Saturday',
            'draw_time': time(23, 21)
        },
        {
            'name': 'Brazil Mega Sena',
            'country': 'Brazil',
            'flag_emoji': '🇧🇷',
            'numbers_count': 6,
            'numbers_range': 60,
            'has_bonus_numbers': False,
            'draw_days': 'Wednesday,Saturday',
            'draw_time': time(20, 0)
        }
    ]
    
    from src.models.user import Lottery
    for lottery_data in lotteries_data:
        existing_lottery = Lottery.query.filter_by(name=lottery_data['name']).first()
        if not existing_lottery:
            lottery = Lottery(**lottery_data)
            db.session.add(lottery)
    
    # Create forum categories
    forum_categories_data = [
        {
            'name': 'General Discussion',
            'description': 'General discussions about lottery syndicates and strategies',
            'display_order': 1
        },
        {
            'name': 'Syndicate Announcements',
            'description': 'Announcements about new syndicates and updates',
            'display_order': 2
        },
        {
            'name': 'Winners Circle',
            'description': 'Celebrate wins and share success stories',
            'display_order': 3
        },
        {
            'name': 'Help & Support',
            'description': 'Get help with using the platform',
            'display_order': 4
        },
        {
            'name': 'Feedback & Suggestions',
            'description': 'Share your feedback and suggestions for improvement',
            'display_order': 5
        }
    ]
    
    from src.models.user import ForumCategory
    for category_data in forum_categories_data:
        existing_category = ForumCategory.query.filter_by(name=category_data['name']).first()
        if not existing_category:
            category = ForumCategory(**category_data)
            db.session.add(category)
    
    # Commit all changes
    db.session.commit()
    print("Database initialized with default data")

