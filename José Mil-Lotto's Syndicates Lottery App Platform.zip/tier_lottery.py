from flask import Blueprint, request, jsonify, session
from src.models.user import db, User, Tier, Lottery, Syndicate, Share, Entry
from datetime import datetime, timedelta
from sqlalchemy import func, desc
import random

tier_bp = Blueprint('tier', __name__)

@tier_bp.route('/user/tier-status', methods=['GET'])
def get_user_tier_status():
    """Get current user's tier status and progress"""
    try:
        if 'user_id' not in session:
            return jsonify({
                'success': False,
                'message': 'Authentication required'
            }), 401
            
        user_id = session['user_id']
        user = User.query.get(user_id)
        
        if not user:
            return jsonify({
                'success': False,
                'message': 'User not found'
            }), 404
        
        # Get all tiers
        tiers = Tier.query.order_by(Tier.level).all()
        
        # Get user statistics
        user_syndicates = Share.query.filter_by(user_id=user_id).count()
        active_syndicates = Share.query.join(Syndicate).filter(
            Share.user_id == user_id,
            Syndicate.status == 'active'
        ).count()
        
        # Calculate next tier progress
        current_tier = user.current_tier
        next_tier = Tier.query.filter(Tier.level > current_tier.level).order_by(Tier.level).first()
        
        progress_to_next = 0
        remaining_to_next = 0
        
        if next_tier:
            progress_to_next = min(100, (float(user.total_winnings) / next_tier.winnings_threshold) * 100)
            remaining_to_next = max(0, next_tier.winnings_threshold - float(user.total_winnings))
        
        return jsonify({
            'success': True,
            'data': {
                'current_tier': {
                    'level': current_tier.level,
                    'name': current_tier.name,
                    'winnings_threshold': float(current_tier.winnings_threshold),
                    'description': current_tier.description
                },
                'next_tier': {
                    'level': next_tier.level,
                    'name': next_tier.name,
                    'winnings_threshold': float(next_tier.winnings_threshold),
                    'description': next_tier.description
                } if next_tier else None,
                'user_stats': {
                    'total_winnings': float(user.total_winnings),
                    'total_syndicates': user_syndicates,
                    'active_syndicates': active_syndicates,
                    'progress_to_next': progress_to_next,
                    'remaining_to_next': remaining_to_next
                },
                'all_tiers': [
                    {
                        'level': tier.level,
                        'name': tier.name,
                        'winnings_threshold': float(tier.winnings_threshold),
                        'description': tier.description,
                        'is_unlocked': tier.level <= current_tier.level,
                        'is_current': tier.level == current_tier.level
                    }
                    for tier in tiers
                ]
            }
        })
        
    except Exception as e:
        return jsonify({
            'success': False,
            'message': f'Error fetching tier status: {str(e)}'
        }), 500

@tier_bp.route('/user/check-tier-unlock', methods=['POST'])
def check_tier_unlock():
    """Check if user can unlock a new tier based on winnings"""
    try:
        if 'user_id' not in session:
            return jsonify({
                'success': False,
                'message': 'Authentication required'
            }), 401
            
        user_id = session['user_id']
        user = User.query.get(user_id)
        
        if not user:
            return jsonify({
                'success': False,
                'message': 'User not found'
            }), 404
        
        # Find the highest tier the user can unlock
        available_tier = Tier.query.filter(
            Tier.winnings_threshold <= user.total_winnings,
            Tier.level > user.current_tier.level
        ).order_by(desc(Tier.level)).first()
        
        if available_tier:
            # Update user's tier
            user.tier_id = available_tier.id
            db.session.commit()
            
            return jsonify({
                'success': True,
                'message': f'Congratulations! You have unlocked {available_tier.name}!',
                'data': {
                    'new_tier': {
                        'level': available_tier.level,
                        'name': available_tier.name,
                        'winnings_threshold': float(available_tier.winnings_threshold),
                        'description': available_tier.description
                    },
                    'previous_tier': {
                        'level': user.current_tier.level,
                        'name': user.current_tier.name
                    }
                }
            })
        else:
            return jsonify({
                'success': True,
                'message': 'No new tier available to unlock',
                'data': None
            })
        
    except Exception as e:
        db.session.rollback()
        return jsonify({
            'success': False,
            'message': f'Error checking tier unlock: {str(e)}'
        }), 500

@tier_bp.route('/user/add-winnings', methods=['POST'])
def add_user_winnings():
    """Add winnings to user account (for testing tier unlocking)"""
    try:
        if 'user_id' not in session:
            return jsonify({
                'success': False,
                'message': 'Authentication required'
            }), 401
            
        data = request.get_json()
        amount = data.get('amount', 0)
        
        if amount <= 0:
            return jsonify({
                'success': False,
                'message': 'Amount must be positive'
            }), 400
            
        user_id = session['user_id']
        user = User.query.get(user_id)
        
        if not user:
            return jsonify({
                'success': False,
                'message': 'User not found'
            }), 404
        
        # Add winnings
        user.total_winnings += amount
        db.session.commit()
        
        # Check for tier unlock
        available_tier = Tier.query.filter(
            Tier.winnings_threshold <= user.total_winnings,
            Tier.level > user.current_tier.level
        ).order_by(desc(Tier.level)).first()
        
        tier_unlocked = None
        if available_tier:
            old_tier = user.current_tier
            user.tier_id = available_tier.id
            db.session.commit()
            
            tier_unlocked = {
                'old_tier': {
                    'level': old_tier.level,
                    'name': old_tier.name
                },
                'new_tier': {
                    'level': available_tier.level,
                    'name': available_tier.name,
                    'description': available_tier.description
                }
            }
        
        return jsonify({
            'success': True,
            'message': f'Added £{amount} to your winnings',
            'data': {
                'new_total_winnings': float(user.total_winnings),
                'tier_unlocked': tier_unlocked
            }
        })
        
    except Exception as e:
        db.session.rollback()
        return jsonify({
            'success': False,
            'message': f'Error adding winnings: {str(e)}'
        }), 500

# Lottery Integration Routes
lottery_integration_bp = Blueprint('lottery_integration', __name__)

@lottery_integration_bp.route('/lotteries/upcoming-draws', methods=['GET'])
def get_upcoming_draws():
    """Get upcoming lottery draws"""
    try:
        # Get all lotteries with their next draw dates
        lotteries = Lottery.query.all()
        
        upcoming_draws = []
        for lottery in lotteries:
            # Calculate next draw date (for demo purposes, using weekly draws)
            next_draw = datetime.now() + timedelta(days=random.randint(1, 7))
            
            # Count available syndicates for this lottery
            available_syndicates = Syndicate.query.filter(
                Syndicate.lottery_id == lottery.id,
                Syndicate.status == 'active'
            ).count()
            
            # Generate random jackpot amount
            jackpot = random.randint(1000000, 50000000)  # £1M to £50M
            
            upcoming_draws.append({
                'lottery_id': lottery.id,
                'lottery_name': lottery.name,
                'lottery_flag': lottery.flag_emoji,
                'format': lottery.get_format(),
                'draw_number': random.randint(1000, 9999),
                'draw_date': next_draw.isoformat(),
                'draw_time': '20:00',  # Standard draw time
                'jackpot': jackpot,
                'available_syndicates': available_syndicates
            })
        
        # Sort by draw date
        upcoming_draws.sort(key=lambda x: x['draw_date'])
        
        return jsonify({
            'success': True,
            'data': upcoming_draws[:10]  # Return next 10 draws
        })
        
    except Exception as e:
        return jsonify({
            'success': False,
            'message': f'Error fetching upcoming draws: {str(e)}'
        }), 500

@lottery_integration_bp.route('/lotteries/recent-results', methods=['GET'])
def get_recent_results():
    """Get recent lottery results"""
    try:
        lotteries = Lottery.query.all()
        
        recent_results = []
        for lottery in lotteries:
            # Generate mock recent results
            for i in range(2):  # 2 recent results per lottery
                draw_date = datetime.now() - timedelta(days=i*7 + random.randint(1, 6))
                
                # Generate winning numbers based on lottery format
                if lottery.format.startswith('7'):
                    # 7 numbers format
                    max_number = int(lottery.format.split()[-2])
                    winning_numbers = sorted(random.sample(range(1, max_number + 1), 7))
                    bonus_numbers = []
                else:
                    # 6 numbers format
                    max_number = int(lottery.format.split()[-2])
                    winning_numbers = sorted(random.sample(range(1, max_number + 1), 6))
                    bonus_numbers = [random.randint(1, 10)]  # Bonus ball
                
                jackpot_won = random.randint(500000, 25000000)  # £500K to £25M
                
                recent_results.append({
                    'lottery_id': lottery.id,
                    'lottery_name': lottery.name,
                    'lottery_flag': lottery.flag_emoji,
                    'draw_number': random.randint(1000, 9999),
                    'draw_date': draw_date.isoformat(),
                    'winning_numbers': winning_numbers,
                    'bonus_numbers': bonus_numbers,
                    'jackpot_won': jackpot_won
                })
        
        # Sort by draw date (most recent first)
        recent_results.sort(key=lambda x: x['draw_date'], reverse=True)
        
        return jsonify({
            'success': True,
            'data': recent_results[:15]  # Return 15 most recent results
        })
        
    except Exception as e:
        return jsonify({
            'success': False,
            'message': f'Error fetching recent results: {str(e)}'
        }), 500

@lottery_integration_bp.route('/lotteries/<int:lottery_id>/statistics', methods=['GET'])
def get_lottery_statistics(lottery_id):
    """Get statistics for a specific lottery"""
    try:
        lottery = Lottery.query.get(lottery_id)
        if not lottery:
            return jsonify({
                'success': False,
                'message': 'Lottery not found'
            }), 404
        
        # Calculate statistics
        total_syndicates = Syndicate.query.filter_by(lottery_id=lottery_id).count()
        active_syndicates = Syndicate.query.filter(
            Syndicate.lottery_id == lottery_id,
            Syndicate.status == 'active'
        ).count()
        
        total_participants = db.session.query(func.count(Share.id)).join(Syndicate).filter(
            Syndicate.lottery_id == lottery_id
        ).scalar() or 0
        
        # Mock additional statistics
        total_winnings = random.randint(100000, 5000000)  # £100K to £5M
        average_jackpot = random.randint(2000000, 15000000)  # £2M to £15M
        
        return jsonify({
            'success': True,
            'data': {
                'lottery': {
                    'id': lottery.id,
                    'name': lottery.name,
                    'country': lottery.country,
                    'country_flag': lottery.flag_emoji,
                    'format': lottery.get_format()
                },
                'statistics': {
                    'total_syndicates': total_syndicates,
                    'active_syndicates': active_syndicates,
                    'total_participants': total_participants,
                    'total_winnings': total_winnings,
                    'average_jackpot': average_jackpot,
                    'draw_frequency': 'Weekly',
                    'next_draw': (datetime.now() + timedelta(days=random.randint(1, 7))).isoformat()
                }
            }
        })
        
    except Exception as e:
        return jsonify({
            'success': False,
            'message': f'Error fetching lottery statistics: {str(e)}'
        }), 500

@lottery_integration_bp.route('/syndicate-performance', methods=['GET'])
def get_syndicate_performance():
    """Get syndicate performance analytics"""
    try:
        user_id = session.get('user_id')
        
        # Get user's syndicates if authenticated
        if user_id:
            user_syndicates = db.session.query(Syndicate).join(Share).filter(
                Share.user_id == user_id
            ).all()
        else:
            user_syndicates = []
        
        performance_data = []
        for syndicate in user_syndicates:
            # Mock performance data
            total_invested = float(syndicate.entry_fee) * syndicate.current_participants
            total_winnings = random.randint(0, int(total_invested * 5))  # 0 to 5x return
            roi = ((total_winnings - total_invested) / total_invested * 100) if total_invested > 0 else 0
            
            performance_data.append({
                'syndicate_id': syndicate.id,
                'syndicate_name': syndicate.name,
                'lottery_name': syndicate.lottery.name,
                'lottery_flag': syndicate.lottery.flag_emoji,
                'total_invested': total_invested,
                'total_winnings': total_winnings,
                'roi_percentage': round(roi, 2),
                'draws_completed': syndicate.completed_draws,
                'draws_remaining': syndicate.duration_draws - syndicate.completed_draws,
                'status': syndicate.status
            })
        
        return jsonify({
            'success': True,
            'data': performance_data
        })
        
    except Exception as e:
        return jsonify({
            'success': False,
            'message': f'Error fetching syndicate performance: {str(e)}'
        }), 500

