from flask import Blueprint, request, jsonify
from src.models.user import db, Syndicate, Share, Entry, Lottery, User, SyndicateType, RiskLevel, FinancialEffort, SyndicateStatus, PaymentStatus
from datetime import datetime, date, timedelta
from sqlalchemy import desc, func, and_, or_
from decimal import Decimal
import random

syndicate_bp = Blueprint('syndicate', __name__)

@syndicate_bp.route('/syndicates', methods=['GET'])
def get_syndicates():
    """Get syndicates with filtering and pagination"""
    try:
        page = request.args.get('page', 1, type=int)
        per_page = request.args.get('per_page', 20, type=int)
        lottery_id = request.args.get('lottery_id', type=int)
        syndicate_type = request.args.get('type')
        risk_level = request.args.get('risk')
        financial_effort = request.args.get('effort')
        tier_level = request.args.get('tier', type=int)
        status = request.args.get('status')
        search = request.args.get('search')
        sort_by = request.args.get('sort_by', 'created_at')
        sort_order = request.args.get('sort_order', 'desc')
        
        query = Syndicate.query
        
        # Apply filters
        if lottery_id:
            query = query.filter(Syndicate.lottery_id == lottery_id)
        if syndicate_type:
            query = query.filter(Syndicate.syndicate_type == SyndicateType(syndicate_type))
        if risk_level:
            query = query.filter(Syndicate.risk_level == RiskLevel(risk_level))
        if financial_effort:
            query = query.filter(Syndicate.financial_effort == FinancialEffort(financial_effort))
        if tier_level:
            query = query.filter(Syndicate.tier_level <= tier_level)
        if status:
            query = query.filter(Syndicate.status == SyndicateStatus(status))
        if search:
            query = query.filter(Syndicate.name.contains(search))
        
        # Apply sorting
        if sort_by == 'name':
            order_column = Syndicate.name
        elif sort_by == 'start_date':
            order_column = Syndicate.start_date
        elif sort_by == 'share_price':
            order_column = Syndicate.share_price
        elif sort_by == 'available_shares':
            order_column = Syndicate.available_shares
        else:
            order_column = Syndicate.created_at
        
        if sort_order == 'desc':
            order_column = desc(order_column)
        
        query = query.order_by(order_column)
        
        # Paginate
        pagination = query.paginate(
            page=page, 
            per_page=per_page, 
            error_out=False
        )
        
        syndicates = []
        for syndicate in pagination.items:
            syndicate_data = syndicate.to_dict()
            syndicate_data['creator'] = syndicate.creator.username if syndicate.creator else None
            syndicates.append(syndicate_data)
        
        return jsonify({
            'success': True,
            'data': syndicates,
            'pagination': {
                'page': page,
                'per_page': per_page,
                'total': pagination.total,
                'pages': pagination.pages,
                'has_next': pagination.has_next,
                'has_prev': pagination.has_prev
            }
        })
    except Exception as e:
        return jsonify({
            'success': False,
            'error': str(e)
        }), 500

@syndicate_bp.route('/syndicates/<int:syndicate_id>', methods=['GET'])
def get_syndicate(syndicate_id):
    """Get a specific syndicate by ID"""
    try:
        syndicate = Syndicate.query.get_or_404(syndicate_id)
        syndicate_data = syndicate.to_dict()
        syndicate_data['creator'] = syndicate.creator.username if syndicate.creator else None
        
        # Get shares information
        shares = Share.query.filter_by(syndicate_id=syndicate_id).all()
        syndicate_data['shares'] = [share.to_dict() for share in shares]
        
        # Get entries information
        entries = Entry.query.filter_by(syndicate_id=syndicate_id).all()
        syndicate_data['entries'] = [entry.to_dict() for entry in entries]
        
        return jsonify({
            'success': True,
            'data': syndicate_data
        })
    except Exception as e:
        return jsonify({
            'success': False,
            'error': str(e)
        }), 500

@syndicate_bp.route('/syndicates', methods=['POST'])
def create_syndicate():
    """Create a new syndicate"""
    try:
        data = request.get_json()
        
        # Validate required fields
        required_fields = ['name', 'creator_id', 'lottery_id', 'syndicate_type', 'risk_level', 'financial_effort', 'start_date']
        for field in required_fields:
            if field not in data:
                return jsonify({
                    'success': False,
                    'error': f'Missing required field: {field}'
                }), 400
        
        # Validate creator exists
        creator = User.query.get(data['creator_id'])
        if not creator:
            return jsonify({
                'success': False,
                'error': 'Creator not found'
            }), 404
        
        # Validate lottery exists
        lottery = Lottery.query.get(data['lottery_id'])
        if not lottery:
            return jsonify({
                'success': False,
                'error': 'Lottery not found'
            }), 404
        
        # Calculate syndicate parameters based on type
        syndicate_type = SyndicateType(data['syndicate_type'])
        if syndicate_type == SyndicateType.STANDARD:
            total_shares = 10
            total_draws = 8
            max_entries = 333
        else:  # SUPER
            total_shares = 100
            total_draws = 4
            max_entries = 999
        
        # Calculate share price based on financial effort and risk level
        base_price = 10.0  # Base price in GBP
        effort_multiplier = {
            FinancialEffort.MINIMUM: 1.0,
            FinancialEffort.MEDIUM: 3.0,
            FinancialEffort.MAXIMUM: 8.0
        }
        risk_multiplier = {
            RiskLevel.CAUTIOUS: 1.0,
            RiskLevel.AMBITIOUS: 1.5,
            RiskLevel.AUDACIOUS: 2.0
        }
        
        financial_effort = FinancialEffort(data['financial_effort'])
        risk_level = RiskLevel(data['risk_level'])
        
        share_price = base_price * effort_multiplier[financial_effort] * risk_multiplier[risk_level]
        
        # Calculate number of entries based on share price and type
        if syndicate_type == SyndicateType.STANDARD:
            total_entries = min(int(share_price * 10), max_entries)
        else:
            total_entries = min(int(share_price * 25), max_entries)
        
        # Parse start date
        start_date = datetime.strptime(data['start_date'], '%Y-%m-%d').date()
        end_date = start_date + timedelta(weeks=total_draws)
        
        # Determine tier level based on risk and effort
        tier_level = 1
        if risk_level == RiskLevel.AUDACIOUS and financial_effort == FinancialEffort.MAXIMUM:
            tier_level = 3
        elif risk_level == RiskLevel.AMBITIOUS or financial_effort == FinancialEffort.MEDIUM:
            tier_level = 2
        
        # Create syndicate
        syndicate = Syndicate(
            name=data['name'],
            creator_id=data['creator_id'],
            lottery_id=data['lottery_id'],
            syndicate_type=syndicate_type,
            risk_level=risk_level,
            financial_effort=financial_effort,
            tier_level=tier_level,
            start_date=start_date,
            end_date=end_date,
            total_draws=total_draws,
            remaining_draws=total_draws,
            total_entries=total_entries,
            total_shares=total_shares,
            available_shares=total_shares - 2,  # Reserve 1 for creator, 1 for Mil-Lotto
            share_price=Decimal(str(share_price)),
            description=data.get('description', '')
        )
        
        db.session.add(syndicate)
        db.session.flush()  # Get the syndicate ID
        
        # Create creator's share
        creator_share = Share(
            syndicate_id=syndicate.id,
            user_id=data['creator_id'],
            percentage=Decimal(str(100.0 / total_shares)),
            payment_status=PaymentStatus.COMPLETED,
            payment_reference='CREATOR'
        )
        db.session.add(creator_share)
        
        # Create Mil-Lotto's share (always the last share)
        mil_lotto_share = Share(
            syndicate_id=syndicate.id,
            user_id=None,
            percentage=Decimal(str(100.0 / total_shares)),
            payment_status=PaymentStatus.COMPLETED,
            payment_reference='SYSTEM',
            is_mil_lotto_share=True
        )
        db.session.add(mil_lotto_share)
        
        # Generate random entries for the syndicate
        generate_syndicate_entries(syndicate, lottery)
        
        db.session.commit()
        
        return jsonify({
            'success': True,
            'data': syndicate.to_dict(),
            'message': 'Syndicate created successfully'
        }), 201
        
    except Exception as e:
        db.session.rollback()
        return jsonify({
            'success': False,
            'error': str(e)
        }), 500

@syndicate_bp.route('/syndicates/<int:syndicate_id>/join', methods=['POST'])
def join_syndicate(syndicate_id):
    """Join a syndicate"""
    try:
        data = request.get_json()
        user_id = data.get('user_id')
        
        if not user_id:
            return jsonify({
                'success': False,
                'error': 'User ID is required'
            }), 400
        
        # Validate user exists
        user = User.query.get(user_id)
        if not user:
            return jsonify({
                'success': False,
                'error': 'User not found'
            }), 404
        
        # Validate syndicate exists
        syndicate = Syndicate.query.get(syndicate_id)
        if not syndicate:
            return jsonify({
                'success': False,
                'error': 'Syndicate not found'
            }), 404
        
        # Check if syndicate is available for joining
        if syndicate.status != SyndicateStatus.PENDING:
            return jsonify({
                'success': False,
                'error': 'Syndicate is not available for joining'
            }), 400
        
        # Check if shares are available
        if syndicate.available_shares <= 0:
            return jsonify({
                'success': False,
                'error': 'No shares available'
            }), 400
        
        # Check if user meets tier requirements
        if not user.can_access_tier(syndicate.tier_level):
            return jsonify({
                'success': False,
                'error': f'User tier level {user.get_tier_level()} is insufficient. Required: {syndicate.tier_level}'
            }), 403
        
        # Check if user already has a share in this syndicate
        existing_share = Share.query.filter_by(
            syndicate_id=syndicate_id,
            user_id=user_id
        ).first()
        
        if existing_share:
            return jsonify({
                'success': False,
                'error': 'User already has a share in this syndicate'
            }), 400
        
        # Create share for user
        share = Share(
            syndicate_id=syndicate_id,
            user_id=user_id,
            percentage=Decimal(str(100.0 / syndicate.total_shares)),
            payment_status=PaymentStatus.COMPLETED,  # In real app, this would be PENDING until payment
            payment_reference=f'USER_{user_id}_{syndicate_id}'
        )
        
        # Update available shares
        syndicate.available_shares -= 1
        
        # If syndicate is full, activate it
        if syndicate.available_shares == 0:
            syndicate.status = SyndicateStatus.ACTIVE
        
        db.session.add(share)
        db.session.commit()
        
        return jsonify({
            'success': True,
            'data': share.to_dict(),
            'message': 'Successfully joined syndicate'
        }), 201
        
    except Exception as e:
        db.session.rollback()
        return jsonify({
            'success': False,
            'error': str(e)
        }), 500

@syndicate_bp.route('/syndicates/stats', methods=['GET'])
def get_syndicate_stats():
    """Get syndicate statistics"""
    try:
        total_syndicates = Syndicate.query.count()
        active_syndicates = Syndicate.query.filter_by(status=SyndicateStatus.ACTIVE).count()
        total_shares = Share.query.count()
        total_winnings = db.session.query(func.sum(Entry.winnings)).scalar() or 0
        
        return jsonify({
            'success': True,
            'data': {
                'total_syndicates': total_syndicates,
                'active_syndicates': active_syndicates,
                'total_shares': total_shares,
                'total_winnings': float(total_winnings)
            }
        })
    except Exception as e:
        return jsonify({
            'success': False,
            'error': str(e)
        }), 500

def generate_syndicate_entries(syndicate, lottery):
    """Generate random entries for a syndicate"""
    for i in range(syndicate.total_entries):
        # Generate random numbers
        numbers = sorted(random.sample(range(1, lottery.numbers_range + 1), lottery.numbers_count))
        numbers_str = ','.join(map(str, numbers))
        
        bonus_numbers_str = None
        if lottery.has_bonus_numbers:
            bonus_numbers = sorted(random.sample(range(1, lottery.bonus_range + 1), lottery.bonus_count))
            bonus_numbers_str = ','.join(map(str, bonus_numbers))
        
        entry = Entry(
            syndicate_id=syndicate.id,
            numbers_selected=numbers_str,
            bonus_numbers=bonus_numbers_str,
            draw_number=1  # Will be updated when draws are processed
        )
        db.session.add(entry)

